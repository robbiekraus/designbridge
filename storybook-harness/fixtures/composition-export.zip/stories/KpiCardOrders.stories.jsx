// Rendert echte shadcn-Komponenten: Badge, Card
import { KpiCardOrders } from '../components/KpiCardOrders';

export default {
  title: 'Molecules/KPI Card Orders',
  component: KpiCardOrders,
};

export const Default = {};
