// Rendert echte shadcn-Komponenten: Badge, Button, Card
import { KpiCardRevenue } from '../components/KpiCardRevenue';

export default {
  title: 'Molecules/KPI Card Revenue',
  component: KpiCardRevenue,
};

export const Default = {};
