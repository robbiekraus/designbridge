// Rendert echte shadcn-Komponenten: Button
import { PrimaryAction } from '../components/PrimaryAction';

export default {
  title: 'Atoms/Primary Action',
  component: PrimaryAction,
};

export const Default = {};
