import { DashboardCardsRow } from '../components/DashboardCardsRow';

export default {
  title: 'Organisms/Dashboard Cards Row',
  component: DashboardCardsRow,
};

export const Default = {};
