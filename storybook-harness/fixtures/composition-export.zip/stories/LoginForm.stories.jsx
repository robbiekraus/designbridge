// Rendert echte shadcn-Komponenten: Button, Input, Label
import { LoginForm } from '../components/LoginForm';

export default {
  title: 'Molecules/Login Form',
  component: LoginForm,
};

export const Default = {};
