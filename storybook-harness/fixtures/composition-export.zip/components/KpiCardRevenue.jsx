import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function KpiCardRevenue({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[260px] p-[20px]">
          <span className="text-[14px] font-normal text-[#71717a] self-stretch">Revenue</span>
          <span className="text-[28px] font-bold text-primary self-stretch">$ 96.534</span>
          <div className="flex items-center self-stretch">
            <Badge variant="secondary">+8.2%</Badge>
            <span className="text-[12px] font-normal text-[#a1a1aa]">vs. last month</span>
          </div>
          <Button variant="outline" size="sm">Details</Button>
        </Card>
      </div>
  );
}
