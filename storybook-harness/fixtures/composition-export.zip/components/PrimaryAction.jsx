import { Button } from "@/components/ui/button";

export function PrimaryAction({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Button>Speichern</Button>
      </div>
  );
}
