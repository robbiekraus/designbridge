import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function LoginForm({ className = "", ...props }) {
  return (
      <div className={`flex flex-col items-start p-[24px] bg-[#ffffff] border border-border ${className}`} {...props}>
        <Label>E-Mail</Label>
        <Input />
        <Button>Anmelden</Button>
      </div>
  );
}
