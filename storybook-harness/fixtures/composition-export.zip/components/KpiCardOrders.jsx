import { Badge } from "@/components/ui/badge";
import { Card } from "@/components/ui/card";

export function KpiCardOrders({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[260px] p-[20px]">
          <span className="text-[14px] font-normal text-[#71717a] self-stretch">Orders</span>
          <div className="flex items-center self-stretch">
            <span className="text-[28px] font-bold text-primary">13.465</span>
            <Badge variant="secondary">3.1%</Badge>
          </div>
          <span className="text-[12px] font-normal text-[#a1a1aa] self-stretch">Last month: 11.246</span>
        </Card>
      </div>
  );
}
