export function DashboardCardsRow({ className = "", ...props }) {
  return (
      <div className={`flex items-start p-[16px] ${className}`} {...props}>
        <div className="flex flex-col items-start self-stretch w-[260px] p-[20px] bg-[#ffffff] border border-border">
          <span className="text-[14px] font-normal text-[#71717a] self-stretch">Orders</span>
          <span className="text-[28px] font-bold text-[#000000] self-stretch">13.465</span>
          <span className="text-[12px] font-normal text-[#000000] self-stretch">3.1% Last month: 11.246</span>
        </div>
        <div className="flex flex-col items-start self-stretch w-[260px] p-[20px] bg-[#ffffff] border border-border">
          <span className="text-[14px] font-normal text-[#71717a] self-stretch">Revenue</span>
          <span className="text-[28px] font-bold text-[#000000] self-stretch">$ 96.534</span>
          <span className="text-[12px] font-normal text-[#000000] self-stretch">+8.2% vs. last month Details</span>
        </div>
      </div>
  );
}
