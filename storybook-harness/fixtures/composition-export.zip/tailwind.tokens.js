// DesignBridge — generated Tailwind tokens
// Usage: import tokens from './tokens/tailwind.config.tokens.js'
//        export default { theme: { extend: tokens } }
export default {
  colors: {
    'primary': 'var(--color-primary)',
    'border': 'var(--color-border)',
  },
};
