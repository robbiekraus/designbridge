# DesignBridge — Storybook-Paket

Aus einem Scan erzeugte Komponenten samt Stories (Component Story Format).

## Reinlegen

1. In ein bestehendes React+Vite-Projekt kopieren (oder `npx storybook@latest init`).
2. `components/` und `stories/` sowie `.storybook/main.js` übernehmen.
3. `npm run storybook` — die Bausteine erscheinen nach Ebene gruppiert.

## Inhalt

- `stories/PrimaryAction.stories.jsx` — shadcn: Button
- `stories/KpiCardOrders.stories.jsx` — shadcn: Badge, Card
- `stories/KpiCardRevenue.stories.jsx` — shadcn: Badge, Button, Card
- `stories/LoginForm.stories.jsx` — shadcn: Button, Input, Label
