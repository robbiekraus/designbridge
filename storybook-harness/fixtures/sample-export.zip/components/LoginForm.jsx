import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";

export function LoginForm({ className = "", ...props }) {
  return (
      <div className={`p-[24px] bg-[#ffffff] border border-[#e4e4e7] ${className}`} {...props}>
        <Label>E-Mail</Label>
        <Input />
        <Label>Passwort</Label>
        <Input />
        <Button>Anmelden</Button>
      </div>
  );
}
