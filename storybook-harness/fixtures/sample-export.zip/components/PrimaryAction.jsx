import { Button } from "@/components/ui/button";

export function PrimaryAction({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Button>Speichern</Button>
      </div>
  );
}
