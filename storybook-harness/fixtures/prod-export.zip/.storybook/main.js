// Von DesignBridge erzeugt — in ein Storybook-Projekt kippen (Storybook 8, react-vite).
export default {
  stories: ['../stories/**/*.stories.jsx'],
  addons: ['@storybook/addon-essentials'],
  framework: { name: '@storybook/react-vite', options: {} },
};
