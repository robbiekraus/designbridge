import { Card } from "@/components/ui/card";

export function ShoppingCartPerformanceCard({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Shopping cart performance Initiated Session: 7421 42.1% Abandonment rate 64 of 80 16.6% Bounce rate 85 of 143 22% Completion rate 123 of 243 45.32%</Card>
      </div>
  );
}
