export function ProductTableRow({ className = "", ...props }) {
  return (
      <div className={`flex items-center w-[100px] px-gap-between-icon-and-text py-internal-padding-for-sidebar-items bg-background-card border border-[#e5e7eb] ${className}`} {...props}>
        <div className="flex w-[12px]">
          <span className="text-caption font-caption text-[#18181b]">1</span>
        </div>
        <div className="flex items-center flex-1">
          <div className="w-[52px] h-[52px] bg-[#e5e2dc]">
            <svg width="52" height="52" viewBox="0 0 52 52" fill="none" xmlns="http://www.w3.org/2000/svg"><rect width="52" height="52" fill="#E3DFC7"></rect><path d="M18 52C18 42 22 36 26 36C30 36 34 42 34 52H18Z" fill="#EDE8DF"></path><path d="M14 52C14 40 18 28 26 28C34 28 38 40 38 52H14Z" fill="#18181B"></path><path d="M22 22C22 24.2091 23.7909 26 26 26C28.2091 26 30 24.2091 30 22C30 19.7909 28.2091 18 26 18C23.7909 18 22 19.7909 22 22Z" fill="#D1A993"></path><path d="M20 16C19 20 19 26 21 28C22 22 23 18 26 18C29 18 30 22 31 28C33 26 33 20 32 16C30 14 22 14 20 16Z" fill="#27272A"></path></svg>
          </div>
          <div>
            <span className="text-heading-m font-heading-m text-[#18181b] leading-[1px] self-stretch">Olive Women Padded Jacket</span>
            <span className="text-caption font-caption text-[#71717a] leading-[1px] self-stretch">Jacket</span>
          </div>
        </div>
        <div className="flex w-[100px]">
          <span className="text-[15px] font-normal text-[#18181b] text-right">$26.31</span>
        </div>
        <div className="flex w-[80px]">
          <span className="text-[15px] font-normal text-[#18181b] text-right">432</span>
        </div>
        <div className="flex w-[100px]">
          <span className="text-[15px] font-normal text-[#18181b] text-right">$11.232</span>
        </div>
        <div className="flex justify-end items-center w-[120px]">
          <div className="w-[48px] h-[6px] bg-[#e5e7eb]">
            <div className="flex flex-1 w-[50px] bg-[#688eea]" />
          </div>
          <span className="text-[15px] font-semibold text-[#18181b]">50%</span>
        </div>
      </div>
  );
}
