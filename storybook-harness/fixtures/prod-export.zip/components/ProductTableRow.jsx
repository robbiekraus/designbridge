export function ProductTableRow({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] px-[20px] py-[12px] bg-background-surface border border-[#f0f0f0] ${className}`} {...props}>
        <div className="flex items-center flex-1">
          <span className="text-caption font-caption text-[#4b5563]">1</span>
          <div className="flex items-center">
            <div className="flex justify-center items-center w-[48px] h-[48px] bg-[#d1d5db]">
              <svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" width="12" height="12" fill="none" stroke="#9ca3af" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><path d="M21 15l-5-5L5 21"/></svg>
            </div>
            <div>
              <span className="text-[15px] font-semibold text-[#1f2937] self-stretch">Olive Women Padded Jacket</span>
              <span className="text-caption font-caption text-[#9ca3af] self-stretch">Jacket</span>
            </div>
          </div>
        </div>
        <div className="flex items-center">
          <span className="text-caption font-caption text-[#1f2937]">$26.31</span>
          <span className="text-caption font-caption text-[#1f2937]">432</span>
          <span className="text-caption font-caption text-[#1f2937]">$11.232</span>
          <div className="flex items-center">
            <div className="flex w-[48px] h-[6px] bg-[#f1f5f9]">
              <div className="flex self-stretch w-[50px] bg-[#647acb]" />
            </div>
            <span className="text-body-medium font-body-medium text-[#111827]">50%</span>
          </div>
        </div>
      </div>
  );
}
