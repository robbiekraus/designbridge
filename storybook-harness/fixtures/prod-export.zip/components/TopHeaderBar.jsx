import { Button } from "@/components/ui/button";

export function TopHeaderBar({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] h-[56px] px-[20px] bg-[#f6f6fa] ${className}`} {...props}>
        <div className="flex items-center">
          <Button variant="ghost" size="icon" />
          <span className="text-[15px] font-semibold text-[#111827]">Dashboard</span>
        </div>
        <div className="flex items-center">
          <Button variant="ghost" size="icon" />
          <Button variant="ghost" size="icon" />
        </div>
      </div>
  );
}
