import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function LeftSidebarNavigation({ className = "", ...props }) {
  return (
      <div className={`flex items-start bg-background-card ${className}`} {...props}>
        <div className="flex flex-col items-center self-stretch w-[72px] py-[20px] bg-background-card border border-[#eff1f5]">
          <div className="flex justify-center items-center w-[40px] h-[40px] bg-[#5b73e8]">
            <span className="text-[22px] font-[800] text-background-card leading-[1px]">C</span>
          </div>
          <div className="flex flex-col items-center self-stretch">
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2a10 10 0 1 0 10 10A10 10 0 0 0 12 2zm0 18a8 8 0 1 1 8-8 8 8 0 0 1-8 8z"></path><path d="M12 12l3-3"></path><path d="M12 6v2"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="7" width="20" height="14" rx="2" ry="2"></rect><path d="M16 21V5a2 2 0 0 0-2-2h-4a2 2 0 0 0-2 2v16"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect><path d="M9 12h6M9 16h6"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="16" height="13" rx="2"></rect><path d="M6 21h14a2 2 0 0 0 2-2V8"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle><path d="M23 21v-2a4 4 0 0 0-3-3.87"></path><path d="M16 3.13a4 4 0 0 1 0 7.75"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
              <div className="flex items-start w-[6px] h-[6px] bg-[#22c55e]" />
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M21 16V8a2 2 0 0 0-1-1.73l-7-4a2 2 0 0 0-2 0l-7 4A2 2 0 0 0 3 8v8a2 2 0 0 0 1 1.73l7 4a2 2 0 0 0 2 0l7-4A2 2 0 0 0 21 16z"></path><polyline points="3.27 6.96 12 12.01 20.73 6.96"></polyline><line x1="12" y1="22.08" x2="12" y2="12"></line></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="2" width="16" height="20" rx="2"></rect><line x1="8" y1="6" x2="16" y2="6"></line><line x1="16" y1="14" x2="16" y2="14.01"></line><line x1="12" y1="14" x2="12" y2="14.01"></line><line x1="8" y1="14" x2="8" y2="14.01"></line><line x1="16" y1="18" x2="16" y2="18.01"></line><line x1="12" y1="18" x2="12" y2="18.01"></line><line x1="8" y1="18" x2="8" y2="18.01"></line></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><circle cx="12" cy="12" r="6"></circle><circle cx="12" cy="12" r="2"></circle></svg>
              <div className="flex items-start w-[6px] h-[6px] bg-[#ef4444]" />
            </div>
            <div className="flex justify-center items-start self-stretch h-[1px]">
              <div className="flex justify-center items-center w-[42px] h-[42px] bg-[#eef2ff]">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(91, 115, 232)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="20" x2="18" y2="10"></line><line x1="12" y1="20" x2="12" y2="4"></line><line x1="6" y1="20" x2="6" y2="14"></line></svg>
              </div>
              <div className="flex items-start w-[3px] h-[30px] bg-[#5b73e8]" />
            </div>
            <div className="flex justify-center items-center w-[40px] h-[40px]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(140, 148, 160)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
            </div>
          </div>
          <div className="flex flex-col items-start w-[1px] h-[1px] pt-[20px]">
            <Avatar />
            <div className="flex items-start w-[10px] h-[10px] bg-[#22c55e] border border-background-card border-[2px]" />
          </div>
        </div>
        <div className="flex flex-col items-start self-stretch flex-1 p-card-layout-padding-and-grid-gaps bg-background-card">
          <div className="flex justify-between items-center self-stretch">
            <div className="flex items-center">
              <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#5b73e8]">
                <span className="text-[22px] font-bold text-background-card">C</span>
              </div>
              <div className="flex flex-col items-start">
                <span className="text-[15px] font-bold text-[#1e2022] self-stretch">CRAFTUI LLC</span>
                <span className="text-caption font-caption text-[#8c94a0] self-stretch">8484 Ross Wells</span>
              </div>
            </div>
            <Button variant="secondary" size="icon" />
          </div>
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[18px] font-bold text-[#1e2022] self-stretch">Popular categories</span>
            <span className="text-caption font-caption text-[#8c94a0] self-stretch">Explore most popular product categories</span>
            <div className="flex flex-col items-start self-stretch">
              <Card className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps">
                <div className="flex flex-col items-start">
                  <span className="text-[18px] font-bold text-[#1e2022] self-stretch">1.345</span>
                  <span className="text-caption font-caption text-[#8c94a0] self-stretch">Electronics</span>
                </div>
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#eef2ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(91, 115, 232)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="3" width="20" height="14" rx="2" ry="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line><line x1="12" y1="17" x2="12" y2="21"></line></svg>
                </div>
              </Card>
              <Card className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps">
                <div className="flex flex-col items-start">
                  <span className="text-[18px] font-bold text-[#1e2022] self-stretch">1.042</span>
                  <span className="text-caption font-caption text-[#8c94a0] self-stretch">Accessories</span>
                </div>
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#fff0f2]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(255, 77, 109)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12l4 6-10 12L2 9z"></path><path d="M11 3l-3 6 4 12"></path><path d="M13 3l3 6-4 12"></path><path d="M2 9h20"></path></svg>
                </div>
              </Card>
              <Card className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps">
                <div className="flex flex-col items-start">
                  <span className="text-[18px] font-bold text-[#1e2022] self-stretch">980</span>
                  <span className="text-caption font-caption text-[#8c94a0] self-stretch">Digital goods</span>
                </div>
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#f5f3ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(124, 58, 237)" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="4" width="20" height="16" rx="2"></rect><path d="M6 8h.01M10 8h.01M14 8h.01M18 8h.01M6 12h.01M10 12h.01M14 12h.01M18 12h.01M8 16h8"></path></svg>
                </div>
              </Card>
            </div>
          </div>
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[18px] font-bold text-[#1e2022] self-stretch">Conversion history</span>
            <div className="flex flex-col items-start self-stretch">
              <span className="text-caption font-caption text-[#8c94a0] leading-[1px]">Week to week</span>
              <div className="flex items-start" />
              <span className="text-caption font-caption text-[#8c94a0] leading-[1px]">performance</span>
            </div>
            <Card className="flex flex-col items-start self-stretch pt-[20px] pr-internal-card-padding-and-item-gaps pl-internal-card-padding-and-item-gaps">
              <div className="flex justify-between items-end self-stretch h-[160px] pr-gap-between-small-inline-elements pb-internal-card-padding-and-item-gaps pl-gap-between-small-inline-elements">
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[50px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[30px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[75px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[35px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[85px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[60px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[60px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[65px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[95px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[55px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[88px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[58px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[68px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[66px] bg-[#34d399]" />
                </div>
                <div className="flex items-end self-stretch">
                  <div className="flex items-start w-[4px] h-[78px] bg-[#5b73e8]" />
                  <div className="flex items-start w-[4px] h-[62px] bg-[#34d399]" />
                </div>
              </div>
              <div className="flex items-start self-stretch py-internal-card-padding-and-item-gaps bg-[#fafbfd] border border-[#f0f1f5]">
                <div className="flex flex-col items-start self-stretch flex-1 px-gap-between-small-inline-elements">
                  <span className="text-[16px] font-bold text-[#1e2022] self-stretch">$342.000</span>
                  <span className="text-caption font-caption text-[#8c94a0] self-stretch">Total sales</span>
                </div>
                <div className="flex items-start self-stretch w-[1px] bg-[#f0f1f5]" />
                <div className="flex flex-col items-start self-stretch flex-1 px-gap-between-small-inline-elements">
                  <span className="text-[16px] font-bold text-[#1e2022] self-stretch">$200.000</span>
                  <span className="text-caption font-caption text-[#8c94a0] self-stretch">Spendings</span>
                </div>
              </div>
            </Card>
          </div>
        </div>
      </div>
  );
}
