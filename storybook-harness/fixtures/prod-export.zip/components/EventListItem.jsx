export function EventListItem({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] px-internal-card-padding-and-item-gaps py-[12px] bg-background-card ${className}`} {...props}>
        <div className="flex items-center">
          <div className="flex justify-center items-center w-[48px] h-[48px] bg-[#f0f3ff]">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><polyline points="10 9 9 9 8 9"></polyline></svg>
          </div>
          <div className="flex flex-col items-start">
            <span className="text-[15px] font-bold text-[#111827] self-stretch">Invoice #AA-04-19-1890678</span>
            <span className="text-caption font-caption text-[#4b5563] self-stretch">New Madieton LLC.</span>
          </div>
        </div>
        <span className="text-[16px] font-bold text-[#111827]">$118.00</span>
      </div>
  );
}
