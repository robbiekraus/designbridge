export function ProgressBar({ className = "", ...props }) {
  return (
      <div className={`flex w-[100px] h-[8px] bg-[#f1f3f5] ${className}`} {...props}>
        <div className="flex self-stretch w-[82px] bg-[#6b8de3]" />
      </div>
  );
}
