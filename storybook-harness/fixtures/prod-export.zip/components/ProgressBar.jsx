export function ProgressBar({ className = "", ...props }) {
  return (
      <div className={`w-[100px] h-[12px] bg-[#e2e8f0] ${className}`} {...props}>
        <div className="flex flex-1 w-[60px] bg-[#6c92ea]" />
      </div>
  );
}
