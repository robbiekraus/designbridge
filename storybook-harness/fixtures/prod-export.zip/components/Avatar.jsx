import { Avatar } from "@/components/ui/avatar";

export function Avatar({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Avatar />
      </div>
  );
}
