import { Card } from "@/components/ui/card";

export function TotalSalesLineChartCard({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Total sales $ 96.534 Revenue $ 13.465 Order Aug 1 Aug 2 Aug 3 Aug 4 Aug 5</Card>
      </div>
  );
}
