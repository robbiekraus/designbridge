export function SidebarNavigation({ className = "", ...props }) {
  return (
      <div className={`w-[260px] px-card-internal-padding-padding-small py-card-internal-padding-standard bg-[#eef1f5] ${className}`} {...props}>
        <div className="flex items-center self-stretch pr-gap-between-icon-and-text pb-[28px] pl-gap-between-icon-and-text">
          <div className="flex justify-center items-center w-[40px] h-[40px] bg-[#8167f6]">
            <div className="flex w-[14px] h-[14px] border border-background-surface border-[4px]" />
          </div>
          <span className="text-[19px] font-bold text-[#1c1e23]">Sunstone</span>
        </div>
        <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-[12px] bg-background-surface">
          <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#5e42e2" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="3" width="18" height="18" rx="5"></rect><path d="M7 14l3-3 3 3 4-4"></path></svg>
          <span className="text-heading-lg font-heading-lg text-[#1c1e23]">Overview</span>
        </div>
        <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-[12px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
          <span className="text-body-medium font-body-medium text-[#5e6470]">Inventory</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </div>
        <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-[12px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="8" y="2" width="12" height="16" rx="2"></rect><path d="M4 6v14a2 2 0 0 0 2 2h10"></path></svg>
          <span className="text-body-medium font-body-medium text-[#5e6470]">Sales Orders</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </div>
        <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-[12px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
          <span className="text-body-medium font-body-medium text-[#5e6470]">Stock Control</span>
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
        </div>
        <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-[12px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#5e6470" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1"></rect><line x1="9" y1="12" x2="15" y2="12"></line><line x1="9" y1="16" x2="15" y2="16"></line></svg>
          <span className="text-body-medium font-body-medium text-[#5e6470]">Reporting</span>
        </div>
      </div>
  );
}
