export function SidebarNavigation({ className = "", ...props }) {
  return (
      <div className={`w-[260px] px-internal-padding-for-sidebar-items py-card-internal-padding bg-[#eef0f5] ${className}`} {...props}>
        <div className="flex items-center self-stretch px-gap-between-icon-and-text">
          <div className="flex justify-center items-center w-[40px] h-[40px] bg-[#7a5af8]">
            <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#FFFFFF" strokeWidth="3.5" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="12" r="7"></circle></svg>
          </div>
          <span className="text-[18px] font-bold text-[#101828]">Sunstone</span>
        </div>
        <div className="self-stretch">
          <div className="flex items-center self-stretch px-internal-padding-for-sidebar-items py-internal-padding-for-sidebar-items bg-background-card">
            <div className="flex justify-center items-center w-[32px] h-[32px] border border-[#6941c6] border-[2px]">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6941C6" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M3 12h4l3-8 4 16 3-8h4"></path></svg>
            </div>
            <span className="text-[15px] font-semibold text-[#101828]">Overview</span>
          </div>
          <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-internal-padding-for-sidebar-items">
            <div className="flex items-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M22 19a2 2 0 0 1-2 2H4a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h5l2 3h9a2 2 0 0 1 2 2z"></path></svg>
              <span className="text-body-medium font-body-medium text-[#475467]">Inventory</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </div>
          <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-internal-padding-for-sidebar-items">
            <div className="flex items-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="10" y1="9" x2="8" y2="9"></line></svg>
              <span className="text-body-medium font-body-medium text-[#475467]">Sales Orders</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </div>
          <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-internal-padding-for-sidebar-items">
            <div className="flex items-center">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 0 1-8 0"></path></svg>
              <span className="text-body-medium font-body-medium text-[#475467]">Stock Control</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="9 18 15 12 9 6"></polyline></svg>
          </div>
          <div className="flex items-center self-stretch px-internal-padding-for-sidebar-items py-internal-padding-for-sidebar-items">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#475467" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 4h2a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2H6a2 2 0 0 1-2-2V6a2 2 0 0 1 2-2h2"></path><rect x="8" y="2" width="8" height="4" rx="1" ry="1"></rect><line x1="9" y1="12" x2="15" y2="12"></line><line x1="9" y1="16" x2="15" y2="16"></line></svg>
            <span className="text-body-medium font-body-medium text-[#475467]">Reporting</span>
          </div>
        </div>
      </div>
  );
}
