export function TimePeriodFilter({ className = "", ...props }) {
  return (
      <div className={`flex items-center p-[4px] bg-[#f2f2f5] ${className}`} {...props}>
        <div className="flex items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements bg-background-card">
          <span className="text-[14px] font-semibold text-[#000000]">Day</span>
        </div>
        <div className="flex items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements">
          <span className="text-caption font-caption text-[#62627a]">Week</span>
        </div>
        <div className="flex items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements">
          <span className="text-caption font-caption text-[#62627a]">Month</span>
        </div>
        <div className="flex justify-center items-center px-gap-between-small-inline-elements py-gap-between-small-inline-elements">
          <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#62627a" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
        </div>
      </div>
  );
}
