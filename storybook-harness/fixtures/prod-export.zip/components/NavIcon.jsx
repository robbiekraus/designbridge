export function NavIcon({ className = "", ...props }) {
  return (
      <div className={`flex flex-col items-center w-[56px] py-[12px] bg-background-card ${className}`} {...props}>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M 12 15 L 17 10"></path><path d="M 4.5 16.5 A 9 9 0 1 1 19.5 16.5"></path><circle cx="12" cy="15" r="1.5" fill="#6e6b7b"></circle></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="8" width="18" height="12" rx="2"></rect><path d="M 8 8 V 5 C 8 4.4 8.4 4 9 4 H 15 C 15.6 4 16 4.4 16 5 V 8"></path><line x1="3" y1="12" x2="21" y2="12"></line><path d="M 11 12 V 13 H 13 V 12"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="5" width="14" height="16" rx="2"></rect><path d="M 9 3 H 15 V 6 H 9 Z"></path><path d="M 9 13 L 11 15 L 15 11"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="7" width="14" height="10" rx="1.5"></rect><rect x="6" y="9.5" width="8" height="5" rx="0.5"></rect><path d="M 8 4 H 18 C 19.1 4 20 4.9 20 6 V 14"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="5" width="16" height="15" rx="2"></rect><line x1="4" y1="9" x2="20" y2="9"></line><circle cx="8" cy="12" r="0.8" fill="#6e6b7b"></circle><circle cx="12" cy="12" r="0.8" fill="#6e6b7b"></circle><circle cx="16" cy="12" r="0.8" fill="#6e6b7b"></circle><circle cx="8" cy="15" r="0.8" fill="#6e6b7b"></circle><circle cx="12" cy="15" r="0.8" fill="#6e6b7b"></circle><circle cx="16" cy="15" r="0.8" fill="#6e6b7b"></circle></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="9" cy="7" r="3.5"></circle><path d="M 3 18 C 3 14.5 5.7 13 9 13 C 10.2 13 11.3 13.2 12.2 13.7"></path><rect x="13" y="15" width="8" height="6" rx="1"></rect><path d="M 15 15 V 13.5 H 19 V 15"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M 3 6 C 3 4.9 3.9 4 5 4 H 17 C 18.1 4 19 4.9 19 6 V 13 C 19 14.1 18.1 15 17 15 H 10 L 6 18 V 15 H 5 C 3.9 15 3 14.1 3 13 V 6 Z"></path><path d="M 8 18 L 12 15 H 18 C 19.1 15 20 15.9 20 17 V 19 L 17 17 H 13"></path></svg>
          <div className="flex items-start w-[7px] h-[7px] bg-[#28c76f] border border-background-card border-[2px]" />
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M 12 3 L 20 7.5 V 16.5 L 12 21 L 4 16.5 V 7.5 Z"></path><path d="M 12 3 V 12"></path><path d="M 12 12 L 20 7.5"></path><path d="M 12 12 L 4 7.5"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="5" y="4" width="14" height="16" rx="2"></rect><rect x="8" y="7" width="8" height="3" rx="0.5"></rect><circle cx="8.5" cy="13" r="0.6" fill="#6e6b7b"></circle><circle cx="12" cy="13" r="0.6" fill="#6e6b7b"></circle><circle cx="15.5" cy="13" r="0.6" fill="#6e6b7b"></circle><circle cx="8.5" cy="16" r="0.6" fill="#6e6b7b"></circle><circle cx="12" cy="16" r="0.6" fill="#6e6b7b"></circle><circle cx="15.5" cy="16" r="0.6" fill="#6e6b7b"></circle></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M 4 5 C 2.9 5 2 5.9 2 7 V 17 C 2 18.1 2.9 19 4 19 H 14 C 15.1 19 16 18.1 16 17 V 9 C 16 7.9 15.1 7 14 7 H 9 L 7 5 H 4 Z"></path><path d="M 16 10 H 20 C 21.1 10 22 10.9 22 12 V 18 C 22 19.1 21.1 20 20 20 H 12"></path></svg>
        </div>
        <div className="flex justify-center items-center w-[40px] h-[40px]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#6e6b7b" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><circle cx="12" cy="13" r="8"></circle><circle cx="12" cy="13" r="5"></circle><circle cx="12" cy="13" r="2"></circle></svg>
          <div className="flex items-start w-[7px] h-[7px] bg-[#ea5455] border border-background-card border-[2px]" />
        </div>
        <div className="flex justify-center items-center w-[56px] h-[48px] bg-[#eee8ff]">
          <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#7367f0" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="5" width="18" height="14" rx="2"></rect><path d="M 4 14 C 7 11 10 15 13 12 C 16 9 18 11 20 10 V 18 H 4 Z" fill="#7367f0" fillOpacity="0.12"></path><path d="M 4 14 C 7 11 10 15 13 12 C 16 9 18 11 20 10"></path></svg>
        </div>
      </div>
  );
}
