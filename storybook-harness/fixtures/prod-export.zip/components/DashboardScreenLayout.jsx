import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export function DashboardScreenLayout({ className = "", ...props }) {
  return (
      <div className={`flex w-[100px] bg-[#eef0f6] ${className}`} {...props}>
        <div className="self-stretch w-[240px] px-internal-padding-for-sidebar-items py-card-internal-padding bg-[#eef0f6]">
          <div className="flex items-center self-stretch pl-gap-between-icon-and-text">
            <div className="flex justify-center items-center w-[32px] h-[32px] bg-[#6366f1]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M12 2A10 10 0 1 0 22 12A10 10 0 0 0 12 2Z"></path><path d="M8 12a4 4 0 0 1 8 0"></path></svg>
            </div>
            <span className="text-[18px] font-bold text-[#0f172a]">Sunstone</span>
          </div>
          <div className="self-stretch">
            <div className="flex items-center self-stretch px-internal-padding-for-sidebar-items py-[12px] bg-background-card">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#6366F1" strokeWidth="2"><rect x="3" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="3" width="7" height="7" rx="1"></rect><rect x="14" y="14" width="7" height="7" rx="1"></rect><rect x="3" y="14" width="7" height="7" rx="1"></rect></svg>
              <span className="text-[14px] font-semibold text-[#0f172a]">Overview</span>
            </div>
            <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-[12px]">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M21 8L12 3L3 8l9 5 9-5z"></path><path d="M3 12l9 5 9-5"></path><path d="M3 17l9 5 9-5"></path></svg>
                <span className="text-body-medium font-body-medium text-[#64748b]">Inventory</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-[12px]">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline></svg>
                <span className="text-body-medium font-body-medium text-[#64748b]">Sales Orders</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex justify-between items-center self-stretch px-internal-padding-for-sidebar-items py-[12px]">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M6 2L3 6v14a2 2 0 0 0 2 2h14a2 2 0 0 0 2-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line></svg>
                <span className="text-body-medium font-body-medium text-[#64748b]">Stock Control</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex items-center self-stretch px-internal-padding-for-sidebar-items py-[12px]">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line></svg>
              <span className="text-body-medium font-body-medium text-[#64748b]">Reporting</span>
            </div>
          </div>
        </div>
        <div className="self-stretch flex-1">
          <div className="flex justify-between items-center self-stretch h-[72px] px-[32px]">
            <div className="w-[320px] h-[1px]">
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94A3B8" strokeWidth="2"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
              <Input />
            </div>
            <div className="flex items-center">
              <Button variant="ghost" size="icon" />
              <div className="flex items-center">
                <Avatar />
                <div>
                  <span className="text-[13px] font-semibold text-[#0f172a] self-stretch">Alexander</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Admin</span>
                </div>
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748B" strokeWidth="2"><path d="M6 9l6 6 6-6"></path></svg>
              </div>
            </div>
          </div>
          <div className="self-stretch pr-[32px] pb-[32px] pl-[32px]">
            <div className="flex justify-between items-end self-stretch">
              <div>
                <span className="text-heading-xl font-heading-xl text-[#0f172a] self-stretch">Hi, Alexander</span>
                <span className="text-caption font-caption text-[#64748b] self-stretch">Take a look for your monthly overview</span>
              </div>
              <Button variant="outline">Monthly (Aug 1 - Sep 30 2020)</Button>
            </div>
            <div className="flex self-stretch">
              <Card>Orders 13.465 Last month: 11.246</Card>
              <Card>Items sold 2.135 Last month: 1.840</Card>
              <Card>Shipping $132.234 Last month: $120.112</Card>
              <Card>Gross sale $87.032 Last month: $88.100</Card>
            </div>
            <div className="flex self-stretch">
              <Card>Total sales $ 96.534 Revenue $ 13.465 Order Aug 1 Aug 2 Aug 3 Aug 4 Aug 5</Card>
              <Card>Shopping cart performance Initiated ↗ 42.1% Session: 7421 Abandonment rate ↘ 16.6% 64 of 80 Bounce rate ↗ 22% 85 of 143 Completion rate ↗ 45.32% 123 of 243</Card>
            </div>
            <div className="flex self-stretch">
              <Card>Top products View all → NO PRODUCT NAME PRICE SOLD SALES REVENUE 1 Olive Women Padded Jacket Jacket $26.31 432 $11.232 50% 2 Veja Volley Sneakers Shoes $76.24 120 $9.120 46% 3 Premium Leather Backpack Premium Bag $80.99 90 $8.189 44% 4 Nike Air Jordan 1 Yellow Red Shoes $170 30 $5.100 38% 5 Matcha Black Longsleeve Shirt $20.10 30 $503 14%</Card>
              <div className="self-stretch">
                <Card>Product share 32.1% Last month: 28% 50% Target</Card>
                <Card>Total order 83.1k Last year: 70%</Card>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}
