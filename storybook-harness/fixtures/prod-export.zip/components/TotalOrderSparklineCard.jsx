import { Card } from "@/components/ui/card";

export function TotalOrderSparklineCard({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Total order 83.1k Last year: 70%</Card>
      </div>
  );
}
