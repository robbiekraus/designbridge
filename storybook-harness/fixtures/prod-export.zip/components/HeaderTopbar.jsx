import { Avatar } from "@/components/ui/avatar";

export function HeaderTopbar({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] h-[72px] px-[28px] bg-[#edf1f5] ${className}`} {...props}>
        <div className="flex items-center flex-1">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#7c8ba1" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <span className="text-[15px] font-normal text-[#9aa6b8]">Search...</span>
        </div>
        <div className="flex items-center">
          <div className="flex justify-center items-center p-[4px]">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#334155" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
          </div>
          <div className="flex items-center pt-gap-between-icon-and-text pr-internal-padding-for-sidebar-items pb-gap-between-icon-and-text pl-gap-between-icon-and-text bg-background-card">
            <Avatar />
            <div className="flex flex-col justify-center">
              <span className="text-[14px] font-bold text-[#1a202c] leading-[1px] self-stretch">Alexander</span>
              <span className="text-caption font-caption text-[#718096] leading-[1px] self-stretch">Admin</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4a5568" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
          </div>
        </div>
      </div>
  );
}
