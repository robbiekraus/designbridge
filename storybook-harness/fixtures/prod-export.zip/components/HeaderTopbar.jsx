import { Avatar } from "@/components/ui/avatar";

export function HeaderTopbar({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] h-[72px] px-grid-gap-between-main-panels bg-[#eef2f6] border border-[#3b82f6] border-[3px] ${className}`} {...props}>
        <div className="flex items-center">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6B7280" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><circle cx="11" cy="11" r="8"></circle><line x1="21" y1="21" x2="16.65" y2="16.65"></line></svg>
          <span className="text-[15px] font-normal text-[#9ca3af]">Search...</span>
        </div>
        <div className="flex items-center">
          <div className="flex justify-center items-center p-gap-between-icon-and-text">
            <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="rgb(75, 85, 99)" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 0 1-3.46 0"></path></svg>
          </div>
          <div className="flex items-center pt-gap-between-icon-and-text pr-card-internal-padding-padding-small pb-gap-between-icon-and-text pl-gap-between-icon-and-text bg-background-surface">
            <Avatar />
            <div className="flex flex-col justify-center">
              <span className="text-[14px] font-semibold text-[#111827] leading-[1px] self-stretch">Alexander</span>
              <span className="text-caption font-caption text-[#6b7280] leading-[1px] self-stretch">Admin</span>
            </div>
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#4B5563" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
          </div>
        </div>
      </div>
  );
}
