import { Avatar } from "@/components/ui/avatar";

export function UserAvatar({ className = "", ...props }) {
  return (
      <div className={`flex justify-center items-center p-[20px] bg-[#edf0f5] ${className}`} {...props}>
        <div className="flex justify-center items-center p-card-internal-padding-standard bg-background-surface">
          <Avatar />
        </div>
      </div>
  );
}
