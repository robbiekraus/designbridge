import { Avatar } from "@/components/ui/avatar";

export function UserAvatar({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Avatar />
      </div>
  );
}
