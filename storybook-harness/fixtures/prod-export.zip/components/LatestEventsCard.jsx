import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function LatestEventsCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[520px]">
          <div className="flex justify-between items-center self-stretch pt-card-layout-padding-and-grid-gaps pr-[28px] pb-[20px] pl-[28px]">
            <span className="text-[18px] font-bold text-[#111827]">Latest Events</span>
            <Button variant="outline" size="sm">View all</Button>
          </div>
          <div className="flex justify-between items-center self-stretch px-[28px] py-[12px] bg-[#fafafd]">
            <span className="text-body-medium font-body-medium text-[#6b7280]">Event</span>
            <span className="text-body-medium font-body-medium text-[#6b7280]">Details</span>
          </div>
          <div className="flex flex-col items-start self-stretch pt-[20px] pr-[28px] pb-card-layout-padding-and-grid-gaps pl-[28px]">
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#eef2ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="10" y1="9" x2="8" y2="9"></line></svg>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-[14px] font-semibold text-[#111827] self-stretch">Invoice #AA-04-19-1890678</span>
                  <span className="text-caption font-caption text-[#6b7280] self-stretch">New Madieton LLC.</span>
                </div>
              </div>
              <span className="text-[14px] font-bold text-[#111827]">$118.00</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#eef2ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="8.5" cy="7" r="4"></circle><line x1="18" y1="11" x2="18" y2="11.01"></line></svg>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-[14px] font-semibold text-[#111827] self-stretch">Client Bernard Stanley</span>
                  <span className="text-caption font-caption text-[#6b7280] self-stretch">bernard.stanley@gmail.com</span>
                </div>
              </div>
              <span className="text-[14px] font-bold text-[#111827]">$3208.00</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#eef2ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polygon points="1 6 1 22 8 18 16 22 23 18 23 2 16 6 8 2 1 6"></polygon><line x1="8" y1="2" x2="8" y2="18"></line><line x1="16" y1="6" x2="16" y2="22"></line></svg>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-[14px] font-semibold text-[#111827] self-stretch">Meeting with the client</span>
                  <span className="text-caption font-caption text-[#6b7280] self-stretch">24 Vandervort Springs</span>
                </div>
              </div>
              <span className="text-[14px] font-semibold text-[#111827]">29 Oct 2019</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <div className="flex justify-center items-center w-[44px] h-[44px] bg-[#eef2ff]">
                  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4f46e5" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path><polyline points="14 2 14 8 20 8"></polyline><line x1="16" y1="13" x2="8" y2="13"></line><line x1="16" y1="17" x2="8" y2="17"></line><line x1="10" y1="9" x2="8" y2="9"></line></svg>
                </div>
                <div className="flex flex-col items-start">
                  <span className="text-[14px] font-semibold text-[#111827] self-stretch">Invoice #AA-04-19-1890243</span>
                  <span className="text-caption font-caption text-[#6b7280] self-stretch">Tyriquemouth LLC.</span>
                </div>
              </div>
              <span className="text-[14px] font-bold text-[#111827]">$578.00</span>
            </div>
          </div>
        </Card>
      </div>
  );
}
