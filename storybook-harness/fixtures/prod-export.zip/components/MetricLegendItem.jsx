export function MetricLegendItem({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] py-[4px] bg-background-card ${className}`} {...props}>
        <div className="flex items-center">
          <svg width="12" height="12" viewBox="0 0 12 12" fill="none" xmlns="http://www.w3.org/2000/svg"><circle cx="6" cy="6" r="6" fill="#5C67E5"></circle><circle cx="6" cy="6" r="2" fill="#FFFFFF"></circle></svg>
          <span className="text-caption font-caption text-[#1f2937] leading-[1px]">Marketing Channels</span>
        </div>
        <span className="text-[13px] font-semibold text-[#000000] leading-[1px]">$22.0k</span>
      </div>
  );
}
