import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function IncomeBreakdownCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[520px] p-[28px]">
          <div className="flex justify-between items-center self-stretch">
            <span className="text-[20px] font-bold text-[#0f172a]">Income Breakdown</span>
            <div className="flex items-center">
              <div className="flex items-center p-[3px] bg-[#f8fafc]">
                <Button size="sm">Day</Button>
                <Button variant="ghost" size="sm">Week</Button>
                <Button variant="ghost" size="sm">Month</Button>
              </div>
              <Button variant="ghost" size="icon" />
            </div>
          </div>
          <div className="flex justify-center items-center w-[260px] h-[260px]">
            <svg width="260" height="260" viewBox="0 0 260 260"><path d="M 143.89 51.22 A 80 80 0 0 1 123.03 209.70" fill="none" stroke="#f5bf58" strokeWidth="32" strokeLinecap="butt"></path><path d="M 118.87 209.22 A 80 80 0 0 1 73.43 186.57" fill="none" stroke="#ff708a" strokeWidth="32" strokeLinecap="butt"></path><path d="M 62.55 179.53 A 80 80 0 0 1 45.91 101.28" fill="none" stroke="#5b82f6" strokeWidth="34" strokeLinecap="butt"></path><path d="M 55.31 101.33 A 80 80 0 0 1 139.75 50.60" fill="none" stroke="#7ce4ab" strokeWidth="32" strokeLinecap="butt"></path><text x="54" y="146" fill="#ffffff" font-size="12" font-weight="600" textAnchor="middle">16%</text></svg>
            <div className="flex flex-col justify-center items-center">
              <span className="text-[32px] font-bold text-[#0f172a]">$85k</span>
            </div>
          </div>
          <div className="flex items-start self-stretch pt-gap-between-small-inline-elements">
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <svg width="14" height="14" viewBox="0 0 14 14"><circle cx="7" cy="7" r="5.5" fill="none" stroke="#5b82f6" strokeWidth="2.5"></circle><circle cx="7" cy="7" r="2.5" fill="#5b82f6"></circle></svg>
                <span className="text-body-medium font-body-medium text-[#334155]">Marketing Channels</span>
              </div>
              <span className="text-[14px] font-bold text-[#0f172a]">$22.0k</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <svg width="14" height="14" viewBox="0 0 14 14"><circle cx="7" cy="7" r="5.5" fill="none" stroke="#f5bf58" strokeWidth="2.5"></circle><circle cx="7" cy="7" r="2.5" fill="#f5bf58"></circle></svg>
                <span className="text-body-medium font-body-medium text-[#334155]">Offline Channels</span>
              </div>
              <span className="text-[14px] font-bold text-[#0f172a]">$18.6k</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <svg width="14" height="14" viewBox="0 0 14 14"><circle cx="7" cy="7" r="5.5" fill="none" stroke="#7ce4ab" strokeWidth="2.5"></circle><circle cx="7" cy="7" r="2.5" fill="#7ce4ab"></circle></svg>
                <span className="text-body-medium font-body-medium text-[#334155]">Direct Sales</span>
              </div>
              <span className="text-[14px] font-bold text-[#0f172a]">$8.4k</span>
            </div>
            <div className="flex justify-between items-center self-stretch">
              <div className="flex items-center">
                <svg width="14" height="14" viewBox="0 0 14 14"><circle cx="7" cy="7" r="5.5" fill="none" stroke="#ff708a" strokeWidth="2.5"></circle><circle cx="7" cy="7" r="2.5" fill="#ff708a"></circle></svg>
                <span className="text-body-medium font-body-medium text-[#334155]">Other Channels</span>
              </div>
              <span className="text-[14px] font-bold text-[#0f172a]">$15.3k</span>
            </div>
          </div>
        </Card>
      </div>
  );
}
