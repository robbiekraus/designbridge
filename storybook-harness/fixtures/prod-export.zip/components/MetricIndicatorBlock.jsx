export function MetricIndicatorBlock({ className = "", ...props }) {
  return (
      <div className={`px-internal-padding-for-sidebar-items py-[12px] bg-background-card ${className}`} {...props}>
        <span className="text-[18px] font-normal text-[#414651] leading-[1px] self-stretch">Orders</span>
        <div className="flex items-center self-stretch">
          <span className="text-[34px] font-bold text-[#181d27] leading-[1px]">13.465</span>
          <div className="flex items-center">
            <div className="flex justify-center items-center w-[26px] h-[26px] bg-[#e8f3ee]">
              <svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="#3D7B66" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"><path d="M4.5 11.5L11.5 4.5M11.5 4.5H5.5M11.5 4.5V10.5"></path></svg>
            </div>
            <span className="text-heading-m font-heading-m text-[#3d7b66] leading-[1px]">3.1%</span>
          </div>
        </div>
        <div className="self-stretch">
          <span className="text-[15px] font-normal text-[#717680] leading-[1px]">Last month:</span>
          <span className="text-[15px] font-semibold text-[#181d27] leading-[1px]">11.246</span>
        </div>
      </div>
  );
}
