export function CategoryItemRow({ className = "", ...props }) {
  return (
      <div className={`flex justify-between items-center w-[100px] px-internal-card-padding-and-item-gaps py-[12px] bg-[#f8f9fe] ${className}`} {...props}>
        <div className="flex flex-col items-start">
          <span className="text-[18px] font-bold text-[#0d0e11] leading-[1px] self-stretch">1.345</span>
          <span className="text-caption font-caption text-[#8a92a6] leading-[1px] self-stretch">Electronics</span>
        </div>
        <div className="flex justify-center items-center w-[42px] h-[42px] bg-[#eef2ff]">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4338ca" strokeWidth="1.8" strokeLinecap="round" strokeLinejoin="round"><path d="M4 6a2 2 0 0 1 2-2h12a2 2 0 0 1 2 2v8H4V6z"></path><path d="M2 17h20"></path></svg>
        </div>
      </div>
  );
}
