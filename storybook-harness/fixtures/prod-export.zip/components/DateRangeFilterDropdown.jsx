export function DateRangeFilterDropdown({ className = "", ...props }) {
  return (
      <div className={`flex justify-center items-center p-card-internal-padding-standard bg-[#ebf0f5] ${className}`} {...props}>
        <div className="flex items-center px-card-internal-padding-standard py-[12px] bg-background-surface border border-[#e1e6ed]">
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#2D3748" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
          <span className="text-[18px] font-normal text-[#1a202c] leading-[1px]">Monthly (Aug 1 - Sep 30 2020)</span>
          <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#4A5568" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
        </div>
      </div>
  );
}
