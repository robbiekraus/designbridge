import { Card } from "@/components/ui/card";

export function PopularCategoriesCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[360px] p-card-layout-padding-and-grid-gaps">
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[18px] font-bold text-[#1a1824] leading-[1px] self-stretch">Popular categories</span>
            <span className="text-caption font-caption text-[#84829a] leading-[1px] self-stretch">Explore most popular product categories</span>
          </div>
          <div className="flex flex-col items-start self-stretch">
            <div className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps bg-[#f9f9fd]">
              <div className="flex flex-col items-start">
                <span className="text-[18px] font-bold text-[#1a1824] self-stretch">1.345</span>
                <span className="text-caption font-caption text-[#84829a] self-stretch">Electronics</span>
              </div>
              <div className="flex justify-center items-center w-[48px] h-[48px] bg-[#edf2fe]">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#3b82f6" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><rect x="4" y="5" width="16" height="10" rx="1.5"></rect><path d="M2 18h20"></path></svg>
              </div>
            </div>
            <div className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps bg-[#f9f9fd]">
              <div className="flex flex-col items-start">
                <span className="text-[18px] font-bold text-[#1a1824] self-stretch">1.042</span>
                <span className="text-caption font-caption text-[#84829a] self-stretch">Accessories</span>
              </div>
              <div className="flex justify-center items-center w-[48px] h-[48px] bg-[#fef2f2]">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#f43f5e" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><path d="M6 3h12l4 6-10 12L2 9z"></path><path d="M11 3l1 18"></path><path d="M2 9h20"></path></svg>
              </div>
            </div>
            <div className="flex justify-between items-center self-stretch px-[20px] py-internal-card-padding-and-item-gaps bg-[#f9f9fd]">
              <div className="flex flex-col items-start">
                <span className="text-[18px] font-bold text-[#1a1824] self-stretch">980</span>
                <span className="text-caption font-caption text-[#84829a] self-stretch">Digital goods</span>
              </div>
              <div className="flex justify-center items-center w-[48px] h-[48px] bg-[#f3f1f8]">
                <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#585375" strokeWidth="1.75" strokeLinecap="round" strokeLinejoin="round"><rect x="2" y="6" width="20" height="12" rx="2"></rect><path d="M6 10h.01M10 10h.01M14 10h.01M18 10h.01M6 14h.01M18 14h.01M9 14h6"></path></svg>
              </div>
            </div>
          </div>
        </Card>
      </div>
  );
}
