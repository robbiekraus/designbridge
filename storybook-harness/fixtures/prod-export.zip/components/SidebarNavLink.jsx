export function SidebarNavLink({ className = "", ...props }) {
  return (
      <div className={`flex items-center px-[20px] py-[12px] bg-background-surface ${className}`} {...props}>
        <div className="flex justify-center items-center w-[32px] h-[32px]">
          <svg width="32" height="32" viewBox="0 0 32 32" fill="none" xmlns="http://www.w3.org/2000/svg"><rect x="2.5" y="2.5" width="27" height="27" rx="9" stroke="#6E56CF" strokeWidth="2.2" fill="none"></rect><path d="M8.5 17.5L12.5 13.5L16 16.5L21.5 11" stroke="#6E56CF" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round"></path></svg>
        </div>
        <span className="text-[19px] font-bold text-[#2d3139]">Overview</span>
      </div>
  );
}
