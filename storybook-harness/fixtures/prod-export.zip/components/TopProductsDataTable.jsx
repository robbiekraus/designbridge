import { Card } from "@/components/ui/card";

export function TopProductsDataTable({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Top products View all NO PRODUCT NAME PRICE SOLD SALES REVENUE 1 Olive Women Padded Jacket Jacket $26.31 432 $11.232 50% 2 Veja Volley Sneakers Shoes $76.24 120 $9.120 46% 3 Premium Leather Backpack Premium Bag $80.99 90 $8.189 44% 4 Nike Air Jordan 1 Yellow Red Shoes $170 30 $5.100 38% 5 Matcha Black Longsleeve Shirt $20.10 30 $503 14%</Card>
      </div>
  );
}
