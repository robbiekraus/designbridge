import { Card } from "@/components/ui/card";

export function IncomeDetailsCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[480px] pt-card-layout-padding-and-grid-gaps">
          <div className="flex justify-between items-center self-stretch px-card-layout-padding-and-grid-gaps">
            <span className="text-[18px] font-bold text-[#1e1e2d]">Income Details</span>
            <div className="flex items-center">
              <div className="flex items-center p-[3px] bg-[#f8f9fc]">
                <div className="flex items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements bg-background-card">
                  <span className="text-[13px] font-semibold text-[#1e1e2d]">Day</span>
                </div>
                <div className="flex items-start px-[12px] py-gap-between-small-inline-elements">
                  <span className="text-body-medium font-body-medium text-[#8a8aa0]">Week</span>
                </div>
                <div className="flex items-start px-[12px] py-gap-between-small-inline-elements">
                  <span className="text-body-medium font-body-medium text-[#8a8aa0]">Month</span>
                </div>
              </div>
              <div className="flex justify-center items-center w-[34px] h-[34px] bg-[#f3f4f8]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#8a8aa0" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start self-stretch pt-[20px] pr-card-layout-padding-and-grid-gaps pl-card-layout-padding-and-grid-gaps">
            <div className="flex items-center self-stretch">
              <span className="text-heading-xl font-heading-xl text-[#1e1e2d]">$142.000</span>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#6EE7B7" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M9 14L4 9l5-5"></path><path d="M4 9h10.5a5.5 5.5 0 0 1 5.5 5.5v0a5.5 5.5 0 0 1-5.5 5.5H11"></path></svg>
            </div>
            <span className="text-caption font-caption text-[#8a8aa0] self-stretch">Total income</span>
          </div>
          <div className="flex flex-col items-start self-stretch h-[140px]">
            <svg width="100%" height="140" viewBox="0 0 480 140" preserveAspectRatio="none"><path d="M0 40 Q75 120 150 100 T300 70 T480 50" fill="none" stroke="#6EE7B7" strokeWidth="2.5"></path><line x1="243" y1="80" x2="243" y2="140" stroke="#6EE7B7" strokeWidth="1.5" strokeDasharray="3 3"></line><circle cx="243" cy="80" r="10" fill="#6EE7B7" fillOpacity="0.3"></circle><circle cx="243" cy="80" r="5" fill="#34D399"></circle></svg>
            <div className="flex flex-col items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements bg-background-card">
              <span className="text-body-medium font-body-medium text-[#8a8aa0] self-stretch">March</span>
              <span className="text-[14px] font-bold text-[#1e1e2d] self-stretch">$48.200</span>
            </div>
          </div>
          <div className="flex items-start self-stretch border border-[#f0f0f5]">
            <div className="flex flex-col items-start self-stretch flex-1 p-internal-card-padding-and-item-gaps border border-[#f0f0f5]">
              <span className="text-[16px] font-bold text-[#1e1e2d] self-stretch">$342.000</span>
              <span className="text-caption font-caption text-[#8a8aa0] self-stretch">Total sales</span>
            </div>
            <div className="flex flex-col items-start self-stretch flex-1 p-internal-card-padding-and-item-gaps border border-[#f0f0f5]">
              <span className="text-[16px] font-bold text-[#1e1e2d] self-stretch">$200.000</span>
              <span className="text-caption font-caption text-[#8a8aa0] self-stretch">Spendings</span>
            </div>
            <div className="flex flex-col items-start self-stretch flex-1 p-internal-card-padding-and-item-gaps">
              <span className="text-[16px] font-bold text-[#1e1e2d] self-stretch">$142.000</span>
              <span className="text-caption font-caption text-[#8a8aa0] self-stretch">Income</span>
            </div>
          </div>
        </Card>
      </div>
  );
}
