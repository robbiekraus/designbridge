export function NavItem({ className = "", ...props }) {
  return (
      <div className={`flex items-center w-[100px] h-[64px] bg-[#eef0f4] ${className}`} {...props}/>
  );
}
