import { Avatar } from "@/components/ui/avatar";

export function UserProfileMenu({ className = "", ...props }) {
  return (
      <div className={`flex items-center pt-gap-between-icon-and-text pr-internal-padding-for-sidebar-items pb-gap-between-icon-and-text pl-gap-between-icon-and-text bg-background-card ${className}`} {...props}>
        <Avatar />
        <div className="flex flex-col justify-center pr-[4px]">
          <span className="text-heading-m font-heading-m text-[#111827] leading-[1px] self-stretch">Alexander</span>
          <span className="text-caption font-caption text-foreground-secondary leading-[1px] self-stretch">Admin</span>
        </div>
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#4b5563" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="6 9 12 15 18 9"></polyline></svg>
      </div>
  );
}
