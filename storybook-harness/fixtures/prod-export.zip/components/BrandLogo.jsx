export function BrandLogo({ className = "", ...props }) {
  return (
      <div className={`flex items-center px-[12px] py-gap-between-icon-and-text bg-[#f0f2f6] ${className}`} {...props}>
        <div className="flex justify-center items-center w-[40px] h-[40px] bg-[#7b62e6]">
          <div className="flex w-[20px] h-[20px] bg-background-card" />
        </div>
        <span className="text-heading-xl font-heading-xl text-[#1a1a1e] leading-[1px]">Sunstone</span>
      </div>
  );
}
