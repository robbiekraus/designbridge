export function BrandLogo({ className = "", ...props }) {
  return (
      <div className={`flex items-center ${className}`} {...props}>
        <div className="flex justify-center items-center w-[40px] h-[40px] bg-[#745ceb]">
          <div className="flex w-[19px] h-[19px] bg-background-surface" />
        </div>
        <span className="text-heading-xl font-heading-xl text-[#18181b] leading-[1px]">Sunstone</span>
      </div>
  );
}
