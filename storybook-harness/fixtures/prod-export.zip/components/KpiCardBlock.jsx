import { Card } from "@/components/ui/card";

export function KpiCardBlock({ className = "", ...props }) {
  return (
      <div className={`flex w-[100px] p-card-internal-padding bg-[#ebf0f5] ${className}`} {...props}>
        <Card>Orders 13.465 3.1% Last month: 11.246</Card>
        <Card>Items sold 2.135 1.2% Last month: 1.840</Card>
        <Card>Shipping $ 132.234 1,8% Last month: $120.112</Card>
        <Card>Gross sale $ 87.032 1,0% Last month: $88.100</Card>
      </div>
  );
}
