import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function YourSalesChartCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[520px] p-[28px]">
          <div className="flex justify-between items-center self-stretch">
            <span className="text-[18px] font-bold text-[#11142d]">Your Sales</span>
            <div className="flex items-center">
              <div className="flex items-center p-[3px] bg-[#f8f8fa]">
                <Button size="sm">Day</Button>
                <Button variant="ghost" size="sm">Week</Button>
                <Button variant="ghost" size="sm">Month</Button>
              </div>
              <div className="flex justify-center items-center w-[34px] h-[34px] bg-[#f4f5f7]">
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#6C5DD3" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><rect x="3" y="4" width="18" height="18" rx="2" ry="2"></rect><line x1="16" y1="2" x2="16" y2="6"></line><line x1="8" y1="2" x2="8" y2="6"></line><line x1="3" y1="10" x2="21" y2="10"></line></svg>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start self-stretch">
            <span className="text-heading-xl font-heading-xl text-[#11142d] self-stretch">$142.000</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Total income</span>
          </div>
          <div className="flex flex-col items-start self-stretch h-[160px]">
            <svg width="100%" height="160" viewBox="0 0 464 160" fill="none"><line x1="42" y1="0" x2="42" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><line x1="120" y1="0" x2="120" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><line x1="198" y1="0" x2="198" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><line x1="276" y1="0" x2="276" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><line x1="354" y1="0" x2="354" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><line x1="432" y1="0" x2="432" y2="160" stroke="#F2F3F5" strokeWidth="1.5" strokeDasharray="3 3"></line><path d="M 0,70 C 25,85 45,98 70,102 C 100,107 125,140 142,140 C 160,140 175,40 205,40 C 225,40 235,55 248,70 C 270,95 295,125 325,125 C 360,125 390,80 425,80 C 445,80 455,88 464,95" fill="none" stroke="#5D5FEF" strokeWidth="2.5" strokeLinecap="round"></path><circle cx="248" cy="70" r="8" fill="#5D5FEF" fillOpacity="0.35"></circle><circle cx="248" cy="70" r="4" fill="#5D5FEF"></circle></svg>
            <div className="flex flex-col items-start px-internal-card-padding-and-item-gaps py-gap-between-small-inline-elements bg-background-card">
              <span className="text-body-medium font-body-medium text-[#808191] self-stretch">March</span>
              <span className="text-[15px] font-bold text-[#11142d] self-stretch">$48.200</span>
            </div>
          </div>
          <div className="flex justify-between items-start self-stretch pt-internal-card-padding-and-item-gaps pr-[20px] pl-[20px]">
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Jan</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Feb</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Mar</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Apr</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Jun</span>
            <span className="text-body-medium font-body-medium text-[#808191] self-stretch">Jul</span>
          </div>
        </Card>
      </div>
  );
}
