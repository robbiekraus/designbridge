import { Avatar } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Input } from "@/components/ui/input";

export function DashboardPageLayout({ className = "", ...props }) {
  return (
      <div className={`w-[100px] bg-[#f0f2f5] ${className}`} {...props}>
        <div className="flex justify-between items-center self-stretch px-card-internal-padding-standard py-[12px] bg-[#f0f2f5] border border-[#e2e8f0]">
          <div className="flex items-center">
            <div className="flex justify-center items-center w-[32px] h-[32px] bg-[#6366f1]">
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="rgb(255, 255, 255)" strokeWidth="2.5"><path d="M12 2L2 7l10 5 10-5-10-5zM2 17l10 5 10-5M2 12l10 5 10-5"></path></svg>
            </div>
            <span className="text-[18px] font-bold text-[#0f172a]">Sunstone</span>
          </div>
          <div className="w-[320px] h-[1px]">
            <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#94a3b8" strokeWidth="2"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>
            <Input />
          </div>
          <div className="flex items-center">
            <div>
              <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2"><path d="M18 8A6 6 0 006 8c0 7-3 9-3 9h18s-3-2-3-9"></path><path d="M13.73 21a2 2 0 01-3.46 0"></path></svg>
            </div>
            <div className="flex items-center">
              <Avatar />
              <div>
                <span className="text-[13px] font-semibold text-[#0f172a] self-stretch">Alexander</span>
                <span className="text-caption font-caption text-[#64748b] self-stretch">Admin</span>
              </div>
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="#64748b" strokeWidth="2"><path d="M6 9l6 6 6-6"></path></svg>
            </div>
          </div>
        </div>
        <div className="flex self-stretch flex-1">
          <div className="self-stretch w-[220px] px-[12px] py-[20px]">
            <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-gap-between-icon-and-text bg-background-surface">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(99, 102, 241)" strokeWidth="2"><rect x="3" y="3" width="7" height="7"></rect><rect x="14" y="3" width="7" height="7"></rect><rect x="14" y="14" width="7" height="7"></rect><rect x="3" y="14" width="7" height="7"></rect></svg>
              <span className="text-[14px] font-semibold text-[#6366f1]">Overview</span>
            </div>
            <div className="flex justify-between items-center self-stretch px-card-internal-padding-padding-small py-gap-between-icon-and-text">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M20 7l-8-4-8 4m16 0l-8 4m8-4v10l-8 4m0-10L4 7m8 4v10M4 7v10l8 4"></path></svg>
                <span className="text-caption font-caption text-[#64748b]">Inventory</span>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex justify-between items-center self-stretch px-card-internal-padding-padding-small py-gap-between-icon-and-text">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M14 2H6a2 2 0 00-2 2v16a2 2 0 002 2h12a2 2 0 002-2V8z"></path><path d="M14 2v6h6"></path></svg>
                <span className="text-caption font-caption text-[#64748b]">Sales Orders</span>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex justify-between items-center self-stretch px-card-internal-padding-padding-small py-gap-between-icon-and-text">
              <div className="flex items-center">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M6 2L3 6v14a2 2 0 002 2h14a2 2 0 002-2V6l-3-4z"></path><line x1="3" y1="6" x2="21" y2="6"></line><path d="M16 10a4 4 0 01-8 0"></path></svg>
                <span className="text-caption font-caption text-[#64748b]">Stock Control</span>
              </div>
              <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 18l6-6-6-6"></path></svg>
            </div>
            <div className="flex items-center self-stretch px-card-internal-padding-padding-small py-gap-between-icon-and-text">
              <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="rgb(100, 116, 139)" strokeWidth="2"><path d="M9 17v-2m3 2v-4m3 4v-6m2 10H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z"></path></svg>
              <span className="text-caption font-caption text-[#64748b]">Reporting</span>
            </div>
          </div>
          <div className="self-stretch flex-1 p-card-internal-padding-standard">
            <div className="flex justify-between items-center self-stretch">
              <div>
                <span className="text-heading-xl font-heading-xl text-[#0f172a] self-stretch">Hi, Alexander</span>
                <span className="text-caption font-caption text-[#64748b] self-stretch">Take a look for your monthly overview</span>
              </div>
              <Button variant="outline">Monthly (Aug 1 - Sep 30 2020)</Button>
            </div>
            <div className="flex self-stretch">
              <Card>Orders 13.465 Last month: 11.246</Card>
              <Card>Items sold 2.135 Last month: 1.840</Card>
              <Card>Shipping $132.234 Last month: $120.112</Card>
              <Card>Gross sale $87.032 Last month: $88.100</Card>
            </div>
            <div className="flex self-stretch">
              <Card>Total sales $96.534 Revenue $13.465 Order Aug 1 Aug 2 Aug 3 Aug 4 Aug 5</Card>
              <Card>Shopping cart performance Initiated ↗ 42.1% Session: 7421 Abandonment rate ↘ 16.6% 64 of 80 Bounce rate ↗ 22% 85 of 143 Completion rate ↗ 45.32% 123 of 243</Card>
            </div>
            <div className="flex self-stretch">
              <Card>Top products View all → NO PRODUCT NAME PRICE SOLD SALES REVENUE 1 Olive Women Padded Jacket Jacket $26.31 432 $11.232 50% 2 Veja Volley Sneakers Shoes $76.24 120 $9.120 46% 3 Premium Leather Backpack Premium Bag $80.99 90 $8.189 44% 4 Nike Air Jordan 1 Yellow Red Shoes $170 30 $5.100 38% 5 Matcha Black Longsleeve Shirt $20.10 30 $503 14%</Card>
              <div className="self-stretch">
                <Card>Product share 32.1% Last month: 28% 50% Target</Card>
                <Card>Total order 83.1k Last year: 70%</Card>
              </div>
            </div>
          </div>
        </div>
      </div>
  );
}
