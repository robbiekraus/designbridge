import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";

export function DashboardPageLayout({ className = "", ...props }) {
  return (
      <div className={`flex items-start w-[100px] bg-[#f4f5f9] ${className}`} {...props}>
        <div className="flex flex-col items-center self-stretch w-[64px] py-internal-card-padding-and-item-gaps bg-background-card border border-[#e2e8f0]">
          <div className="flex justify-center items-center w-[36px] h-[36px] bg-[#3b82f6]">
            <span className="text-[16px] font-bold text-background-card">C</span>
          </div>
          <div className="flex flex-col items-center self-stretch">
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M12 8v8M8 12h8"></path></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="2" y="7" width="20" height="14" rx="2"></rect><path d="M16 3H8"></path></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"></rect></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"></path><circle cx="9" cy="7" r="4"></circle></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"></path></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"></path></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="4" y="4" width="16" height="16" rx="2"></rect></svg>
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
            <div className="flex justify-center items-center w-[24px] h-[24px] bg-[#fee2e2]">
              <svg width="14" height="14" fill="#ef4444" viewBox="0 0 24 24"><path d="M12 2L2 22h20L12 2z"></path></svg>
            </div>
            <svg width="20" height="20" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="3" width="18" height="18" rx="2"></rect></svg>
          </div>
          <div className="flex flex-col items-center">
            <svg width="20" height="20" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="10"></circle><path d="M9.09 9a3 3 0 0 1 5.83 1c0 2-3 3-3 3"></path><line x1="12" y1="17" x2="12.01" y2="17"></line></svg>
            <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#f1f5f9]">
              <span className="text-[12px] font-semibold text-[#1e293b]">👤</span>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-start self-stretch w-[240px] p-internal-card-padding-and-item-gaps bg-[#f8fafc] border border-[#e2e8f0]">
          <div className="flex items-center self-stretch px-[12px] py-gap-between-small-inline-elements bg-background-card border border-[#e2e8f0]">
            <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#3b82f6]">
              <span className="text-[12px] font-bold text-background-card">C</span>
            </div>
            <div className="flex flex-col items-start flex-1">
              <span className="text-[12px] font-bold text-[#1e293b] self-stretch">CRAFTUI LLC</span>
              <span className="text-caption font-caption text-[#64748b] self-stretch">8484 Ross Wells</span>
            </div>
            <svg width="14" height="14" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><path d="M6 9l6 6 6-6"></path></svg>
          </div>
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[12px] font-bold text-[#0f172a] self-stretch">Popular categories</span>
            <span className="text-caption font-caption text-[#94a3b8] self-stretch">Explore most popular product categories</span>
            <div className="flex flex-col items-start self-stretch">
              <div className="flex justify-between items-center self-stretch px-[12px] py-gap-between-small-inline-elements bg-background-card">
                <div className="flex flex-col items-start">
                  <span className="text-[13px] font-bold text-[#1e293b] self-stretch">1.345</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Electronics</span>
                </div>
                <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#eff6ff]">
                  <svg width="14" height="14" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><rect x="2" y="3" width="20" height="14" rx="2"></rect><line x1="8" y1="21" x2="16" y2="21"></line></svg>
                </div>
              </div>
              <div className="flex justify-between items-center self-stretch px-[12px] py-gap-between-small-inline-elements bg-background-card">
                <div className="flex flex-col items-start">
                  <span className="text-[13px] font-bold text-[#1e293b] self-stretch">1.042</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Accessories</span>
                </div>
                <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#fdf2f8]">
                  <svg width="14" height="14" fill="none" stroke="#ec4899" strokeWidth="2" viewBox="0 0 24 24"><path d="M12 2l9 4.9v10.2L12 22l-9-4.9V6.9L12 2z"></path></svg>
                </div>
              </div>
              <div className="flex justify-between items-center self-stretch px-[12px] py-gap-between-small-inline-elements bg-background-card">
                <div className="flex flex-col items-start">
                  <span className="text-[13px] font-bold text-[#1e293b] self-stretch">980</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Digital goods</span>
                </div>
                <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#f5f3ff]">
                  <svg width="14" height="14" fill="none" stroke="#8b5cf6" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="16" rx="2"></rect></svg>
                </div>
              </div>
            </div>
          </div>
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[12px] font-bold text-[#0f172a] self-stretch">Conversion history</span>
            <span className="text-caption font-caption text-[#94a3b8] self-stretch">Week to week performance</span>
            <div className="flex items-end self-stretch h-[120px] pb-[12px] border border-[#f1f5f9]">
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[45px] bg-[#60a5fa]" />
                <div className="flex items-start w-[3px] h-[70px] bg-[#34d399]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[80px] bg-[#60a5fa]" />
                <div className="flex items-start w-[3px] h-[95px] bg-[#34d399]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[60px] bg-[#60a5fa]" />
                <div className="flex items-start w-[3px] h-[75px] bg-[#34d399]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[90px] bg-[#60a5fa]" />
                <div className="flex items-start self-stretch w-[3px] bg-[#34d399]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[50px] bg-[#60a5fa]" />
                <div className="flex items-start w-[3px] h-[85px] bg-[#34d399]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[75px] bg-[#60a5fa]" />
                <div className="flex items-start w-[3px] h-[90px] bg-[#34d399]" />
              </div>
            </div>
            <div className="flex justify-between items-start self-stretch">
              <div className="flex flex-col items-start self-stretch">
                <span className="text-[12px] font-bold text-[#1e293b] self-stretch">$342.000</span>
                <span className="text-caption font-caption text-[#94a3b8] self-stretch">Total sales</span>
              </div>
              <div className="flex flex-col items-start self-stretch">
                <span className="text-[12px] font-bold text-[#1e293b] self-stretch">$200.000</span>
                <span className="text-caption font-caption text-[#94a3b8] self-stretch">Spendings</span>
              </div>
            </div>
          </div>
        </div>
        <div className="flex flex-col items-start self-stretch flex-1">
          <div className="flex justify-between items-center self-stretch h-[56px] px-card-layout-padding-and-grid-gaps bg-background-card border border-[#e2e8f0]">
            <div className="flex items-center">
              <svg width="18" height="18" fill="none" stroke="#64748b" strokeWidth="2" viewBox="0 0 24 24"><line x1="3" y1="12" x2="21" y2="12"></line><line x1="3" y1="6" x2="21" y2="6"></line><line x1="3" y1="18" x2="21" y2="18"></line></svg>
              <span className="text-[16px] font-bold text-[#0f172a]">Dashboard</span>
            </div>
            <div className="flex items-center">
              <svg width="16" height="16" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><circle cx="11" cy="11" r="8"></circle><path d="M21 21l-4.35-4.35"></path></svg>
              <svg width="16" height="16" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><circle cx="12" cy="12" r="9"></circle><path d="M12 8v8M8 12h8"></path></svg>
            </div>
          </div>
          <div className="flex flex-col items-start self-stretch p-card-layout-padding-and-grid-gaps">
            <div className="flex items-start self-stretch">
              <Card className="flex flex-col items-start self-stretch p-[20px]">
                <div className="flex justify-between items-center self-stretch">
                  <span className="text-[14px] font-bold text-[#1e293b]">Your Sales</span>
                  <div className="flex items-center p-[2px] bg-[#f8fafc]">
                    <Button variant="ghost" size="sm">Day</Button>
                    <Button variant="ghost" size="sm">Week</Button>
                    <Button variant="ghost" size="sm">Month</Button>
                    <div className="p-[4px]">
                      <svg width="12" height="12" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"></rect></svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-start self-stretch">
                  <span className="text-[22px] font-bold text-[#1e293b] self-stretch">$142.000</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Total income</span>
                </div>
                <div className="flex flex-col items-start self-stretch h-[140px]">
                  <svg width="100%" height="100%" viewBox="0 0 300 120" preserveAspectRatio="none"><path d="M0,70 Q50,90 80,40 T150,30 T220,70 T300,50" fill="none" stroke="#3b82f6" strokeWidth="2"></path><circle cx="141" cy="38" r="4" fill="#3b82f6" stroke="#ffffff" strokeWidth="2"></circle></svg>
                  <div className="flex flex-col items-start px-gap-between-small-inline-elements py-[4px] bg-background-card">
                    <span className="text-caption font-caption text-[#94a3b8] self-stretch">March</span>
                    <span className="text-[10px] font-bold text-[#1e293b] self-stretch">$48.200</span>
                  </div>
                </div>
                <div className="flex justify-between items-start self-stretch">
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Jan</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Feb</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Mar</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Apr</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Jun</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Jul</span>
                </div>
              </Card>
              <Card className="flex flex-col items-start self-stretch p-[20px]">
                <div className="flex justify-between items-center self-stretch">
                  <span className="text-[14px] font-bold text-[#1e293b]">Latest Events</span>
                  <span className="text-caption font-caption text-[#64748b]">View all</span>
                </div>
                <div className="flex justify-between items-start self-stretch pb-gap-between-small-inline-elements border border-[#f1f5f9]">
                  <span className="text-caption font-caption text-[#cbd5e1] self-stretch">Event</span>
                  <span className="text-caption font-caption text-[#cbd5e1] self-stretch">Details</span>
                </div>
                <div className="flex flex-col items-start self-stretch">
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#eff6ff]">
                        <svg width="14" height="14" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                      </div>
                      <div className="flex flex-col items-start">
                        <span className="text-[12px] font-semibold text-[#1e293b] self-stretch">Invoice #AA-04-19-1890678</span>
                        <span className="text-caption font-caption text-[#94a3b8] self-stretch">New Madieton LLC.</span>
                      </div>
                    </div>
                    <span className="text-[12px] font-bold text-[#1e293b]">$118.00</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#eff6ff]">
                        <svg width="14" height="14" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"></path><circle cx="12" cy="7" r="4"></circle></svg>
                      </div>
                      <div className="flex flex-col items-start">
                        <span className="text-[12px] font-semibold text-[#1e293b] self-stretch">Client Bernard Stanley</span>
                        <span className="text-caption font-caption text-[#94a3b8] self-stretch">bernard.stanley@gmail.com</span>
                      </div>
                    </div>
                    <span className="text-[12px] font-bold text-[#1e293b]">$3208.00</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#eff6ff]">
                        <svg width="14" height="14" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"></rect></svg>
                      </div>
                      <div className="flex flex-col items-start">
                        <span className="text-[12px] font-semibold text-[#1e293b] self-stretch">Meeting with the client</span>
                        <span className="text-caption font-caption text-[#94a3b8] self-stretch">24 Vandervort Springs</span>
                      </div>
                    </div>
                    <span className="text-caption font-caption text-[#64748b]">29 Oct 2019</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex justify-center items-center w-[28px] h-[28px] bg-[#eff6ff]">
                        <svg width="14" height="14" fill="none" stroke="#3b82f6" strokeWidth="2" viewBox="0 0 24 24"><path d="M14 2H6a2 2 0 0 0-2 2v16a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V8z"></path></svg>
                      </div>
                      <div className="flex flex-col items-start">
                        <span className="text-[12px] font-semibold text-[#1e293b] self-stretch">Invoice #AA-04-19-1890243</span>
                        <span className="text-caption font-caption text-[#94a3b8] self-stretch">Tyriquemouth LLC.</span>
                      </div>
                    </div>
                    <span className="text-[12px] font-bold text-[#1e293b]">$578.00</span>
                  </div>
                </div>
              </Card>
            </div>
            <div className="flex items-start self-stretch">
              <Card className="flex flex-col items-start self-stretch p-[20px]">
                <div className="flex justify-between items-center self-stretch">
                  <span className="text-[14px] font-bold text-[#1e293b]">Income Breakdown</span>
                  <div className="flex items-center p-[2px] bg-[#f8fafc]">
                    <Button variant="ghost" size="sm">Day</Button>
                    <Button variant="ghost" size="sm">Week</Button>
                    <Button variant="ghost" size="sm">Month</Button>
                    <div className="p-[4px]">
                      <svg width="12" height="12" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"></rect></svg>
                    </div>
                  </div>
                </div>
                <div className="flex justify-center items-center self-stretch h-[160px]">
                  <svg width="140" height="140" viewBox="0 0 100 100"><path d="M 50 10 A 40 40 0 0 1 90 50" fill="none" stroke="#f59e0b" strokeWidth="16"></path><path d="M 90 50 A 40 40 0 0 1 65 88" fill="none" stroke="#ec4899" strokeWidth="16"></path><path d="M 65 88 A 40 40 0 0 1 20 70" fill="none" stroke="#3b82f6" strokeWidth="16"></path><path d="M 20 70 A 40 40 0 0 1 50 10" fill="none" stroke="#34d399" strokeWidth="16"></path></svg>
                  <div className="flex flex-col items-center">
                    <span className="text-[18px] font-bold text-[#1e293b]">$85k</span>
                  </div>
                  <div className="flex items-start px-[4px] py-[2px] bg-[#3b82f6]">
                    <span className="text-[9px] font-normal text-background-card">16%</span>
                  </div>
                </div>
                <div className="flex items-start self-stretch">
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex items-start w-[8px] h-[8px] bg-[#3b82f6]" />
                      <span className="text-caption font-caption text-[#64748b]">Marketing Channels</span>
                    </div>
                    <span className="text-[11px] font-bold text-[#1e293b]">$22.0k</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex items-start w-[8px] h-[8px] bg-[#f59e0b]" />
                      <span className="text-caption font-caption text-[#64748b]">Offline Channels</span>
                    </div>
                    <span className="text-[11px] font-bold text-[#1e293b]">$18.6k</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex items-start w-[8px] h-[8px] bg-[#34d399]" />
                      <span className="text-caption font-caption text-[#64748b]">Direct Sales</span>
                    </div>
                    <span className="text-[11px] font-bold text-[#1e293b]">$8.4k</span>
                  </div>
                  <div className="flex justify-between items-center self-stretch">
                    <div className="flex items-center">
                      <div className="flex items-start w-[8px] h-[8px] bg-[#ec4899]" />
                      <span className="text-caption font-caption text-[#64748b]">Other Channels</span>
                    </div>
                    <span className="text-[11px] font-bold text-[#1e293b]">$15.3k</span>
                  </div>
                </div>
              </Card>
              <Card className="flex flex-col items-start self-stretch p-[20px]">
                <div className="flex justify-between items-center self-stretch">
                  <span className="text-[14px] font-bold text-[#1e293b]">Income Details</span>
                  <div className="flex items-center p-[2px] bg-[#f8fafc]">
                    <Button variant="ghost" size="sm">Day</Button>
                    <Button variant="ghost" size="sm">Week</Button>
                    <Button variant="ghost" size="sm">Month</Button>
                    <div className="p-[4px]">
                      <svg width="12" height="12" fill="none" stroke="#94a3b8" strokeWidth="2" viewBox="0 0 24 24"><rect x="3" y="4" width="18" height="18" rx="2"></rect></svg>
                    </div>
                  </div>
                </div>
                <div className="flex flex-col items-start self-stretch">
                  <span className="text-[22px] font-bold text-[#1e293b] self-stretch">$142.000</span>
                  <span className="text-caption font-caption text-[#94a3b8] self-stretch">Total income</span>
                </div>
                <div className="flex flex-col items-start self-stretch h-[120px]">
                  <svg width="100%" height="100%" viewBox="0 0 300 100" preserveAspectRatio="none"><path d="M0,80 Q70,20 150,70 T300,30 L300,100 L0,100 Z" fill="#f0fdf4"></path><path d="M0,80 Q70,20 150,70 T300,30" fill="none" stroke="#34d399" strokeWidth="2"></path></svg>
                  <div className="flex flex-col items-start px-gap-between-small-inline-elements py-[4px] bg-background-card">
                    <span className="text-caption font-caption text-[#94a3b8] self-stretch">March</span>
                    <span className="text-[10px] font-bold text-[#1e293b] self-stretch">$48.200</span>
                  </div>
                </div>
                <div className="flex justify-between items-start self-stretch pt-[12px] border border-[#f1f5f9]">
                  <div className="flex flex-col items-start self-stretch">
                    <span className="text-[13px] font-bold text-[#1e293b] self-stretch">$342.000</span>
                    <span className="text-caption font-caption text-[#94a3b8] self-stretch">Total sales</span>
                  </div>
                  <div className="flex flex-col items-start self-stretch">
                    <span className="text-[13px] font-bold text-[#1e293b] self-stretch">$200.000</span>
                    <span className="text-caption font-caption text-[#94a3b8] self-stretch">Spendings</span>
                  </div>
                  <div className="flex flex-col items-start self-stretch">
                    <span className="text-[13px] font-bold text-[#1e293b] self-stretch">$142.000</span>
                    <span className="text-caption font-caption text-[#94a3b8] self-stretch">Income</span>
                  </div>
                </div>
              </Card>
            </div>
          </div>
        </div>
      </div>
  );
}
