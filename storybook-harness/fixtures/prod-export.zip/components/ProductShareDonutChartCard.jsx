import { Card } from "@/components/ui/card";

export function ProductShareDonutChartCard({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Product share 32.1% 3.1% Last month: 28% 50 % Target</Card>
      </div>
  );
}
