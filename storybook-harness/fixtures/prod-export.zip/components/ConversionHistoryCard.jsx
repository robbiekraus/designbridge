import { Card } from "@/components/ui/card";

export function ConversionHistoryCard({ className = "", ...props }) {
  return (
      <div className={`flex items-start ${className}`} {...props}>
        <Card className="flex flex-col items-start w-[340px] p-card-layout-padding-and-grid-gaps">
          <div className="flex flex-col items-start self-stretch">
            <span className="text-[18px] font-bold text-[#18181b] leading-[1px] self-stretch">Conversion history</span>
            <div className="flex flex-col items-start self-stretch">
              <span className="text-caption font-caption text-[#8b8ca7] leading-[1px]">Week to week</span>
              <div className="flex items-start" />
              <span className="text-caption font-caption text-[#8b8ca7] leading-[1px]">performance</span>
            </div>
          </div>
          <div className="self-stretch pt-[20px] pr-internal-card-padding-and-item-gaps pb-[12px] pl-internal-card-padding-and-item-gaps bg-[#fafbff]">
            <div className="flex justify-between items-end self-stretch h-[150px]">
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[60px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[46px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[92px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[42px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[104px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[74px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[68px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[78px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[122px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[62px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[110px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[65px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[78px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[76px] bg-[#86e8b8]" />
              </div>
              <div className="flex items-end self-stretch">
                <div className="flex items-start w-[3px] h-[94px] bg-[#5252eb]" />
                <div className="flex items-start w-[3px] h-[64px] bg-[#86e8b8]" />
              </div>
            </div>
          </div>
          <div className="flex items-start self-stretch border border-[#f3f4f6]">
            <div className="flex flex-col items-start self-stretch flex-1 pt-internal-card-padding-and-item-gaps border border-[#f3f4f6]">
              <span className="text-[18px] font-bold text-[#18181b] self-stretch">$342.000</span>
              <span className="text-caption font-caption text-[#8b8ca7] self-stretch">Total sales</span>
            </div>
            <div className="flex flex-col items-start self-stretch flex-1 pt-internal-card-padding-and-item-gaps pl-[20px]">
              <span className="text-[18px] font-bold text-[#18181b] self-stretch">$200.000</span>
              <span className="text-caption font-caption text-[#8b8ca7] self-stretch">Spendings</span>
            </div>
          </div>
        </Card>
      </div>
  );
}
