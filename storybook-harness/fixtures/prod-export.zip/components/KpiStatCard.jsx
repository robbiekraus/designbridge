import { Card } from "@/components/ui/card";

export function KpiStatCard({ className = "", ...props }) {
  return (
      <div className={`flex ${className}`} {...props}>
        <Card>Orders 13.465 3.1% Last month: 11.246</Card>
      </div>
  );
}
