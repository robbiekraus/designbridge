// Rendert echte shadcn-Komponenten: Card
import { IncomeDetailsCard } from '../components/IncomeDetailsCard';

export default {
  title: 'Organisms/Income Details Card',
  component: IncomeDetailsCard,
};

export const Default = {};
