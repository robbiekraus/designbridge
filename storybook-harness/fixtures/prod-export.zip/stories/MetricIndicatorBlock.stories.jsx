import { MetricIndicatorBlock } from '../components/MetricIndicatorBlock';

export default {
  title: 'Molecules/Metric Indicator Block',
  component: MetricIndicatorBlock,
};

export const Default = {};
