// Rendert echte shadcn-Komponenten: Card
import { ConversionHistoryCard } from '../components/ConversionHistoryCard';

export default {
  title: 'Organisms/Conversion History Card',
  component: ConversionHistoryCard,
};

export const Default = {};
