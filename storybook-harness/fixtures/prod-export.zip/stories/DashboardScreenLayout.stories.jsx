// Rendert echte shadcn-Komponenten: Avatar, Button, Card, Input
import { DashboardScreenLayout } from '../components/DashboardScreenLayout';

export default {
  title: 'Templates/Dashboard Screen Layout',
  component: DashboardScreenLayout,
};

export const Default = {};
