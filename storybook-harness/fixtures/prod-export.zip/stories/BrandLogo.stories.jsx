import { BrandLogo } from '../components/BrandLogo';

export default {
  title: 'Atoms/Brand Logo',
  component: BrandLogo,
};

export const Default = {};
