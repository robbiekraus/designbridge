import { NavIcon } from '../components/NavIcon';

export default {
  title: 'Atoms/Nav Icon',
  component: NavIcon,
};

export const Default = {};
