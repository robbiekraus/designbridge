// Rendert echte shadcn-Komponenten: Avatar
import { Avatar } from '../components/Avatar';

export default {
  title: 'Atoms/Avatar',
  component: Avatar,
};

export const Default = {};
