// Rendert echte shadcn-Komponenten: Card
import { KpiCardBlock } from '../components/KpiCardBlock';

export default {
  title: 'Organisms/KPI Card Block',
  component: KpiCardBlock,
};

export const Default = {};
