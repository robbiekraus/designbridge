import { EventListItem } from '../components/EventListItem';

export default {
  title: 'Molecules/Event List Item',
  component: EventListItem,
};

export const Default = {};
