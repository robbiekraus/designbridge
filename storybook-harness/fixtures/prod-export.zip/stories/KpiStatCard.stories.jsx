// Rendert echte shadcn-Komponenten: Card
import { KpiStatCard } from '../components/KpiStatCard';

export default {
  title: 'Organisms/KPI Stat Card',
  component: KpiStatCard,
};

export const Default = {};
