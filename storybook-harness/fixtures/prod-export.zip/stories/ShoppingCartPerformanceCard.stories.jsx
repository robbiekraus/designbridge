// Rendert echte shadcn-Komponenten: Card
import { ShoppingCartPerformanceCard } from '../components/ShoppingCartPerformanceCard';

export default {
  title: 'Organisms/Shopping Cart Performance Card',
  component: ShoppingCartPerformanceCard,
};

export const Default = {};
