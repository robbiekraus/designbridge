// Rendert echte shadcn-Komponenten: Button, Card
import { LatestEventsCard } from '../components/LatestEventsCard';

export default {
  title: 'Organisms/Latest Events Card',
  component: LatestEventsCard,
};

export const Default = {};
