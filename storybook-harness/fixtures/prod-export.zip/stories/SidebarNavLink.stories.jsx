import { SidebarNavLink } from '../components/SidebarNavLink';

export default {
  title: 'Molecules/Sidebar Nav Link',
  component: SidebarNavLink,
};

export const Default = {};
