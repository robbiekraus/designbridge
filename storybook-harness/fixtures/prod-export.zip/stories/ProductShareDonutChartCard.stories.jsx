// Rendert echte shadcn-Komponenten: Card
import { ProductShareDonutChartCard } from '../components/ProductShareDonutChartCard';

export default {
  title: 'Organisms/Product Share Donut Chart Card',
  component: ProductShareDonutChartCard,
};

export const Default = {};
