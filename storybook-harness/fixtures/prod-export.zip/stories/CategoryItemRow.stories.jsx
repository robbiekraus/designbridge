import { CategoryItemRow } from '../components/CategoryItemRow';

export default {
  title: 'Molecules/Category Item Row',
  component: CategoryItemRow,
};

export const Default = {};
