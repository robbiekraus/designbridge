import { ProductTableRow } from '../components/ProductTableRow';

export default {
  title: 'Molecules/Product Table Row',
  component: ProductTableRow,
};

export const Default = {};
