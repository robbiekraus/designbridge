import { DateRangeFilterDropdown } from '../components/DateRangeFilterDropdown';

export default {
  title: 'Molecules/Date Range Filter Dropdown',
  component: DateRangeFilterDropdown,
};

export const Default = {};
