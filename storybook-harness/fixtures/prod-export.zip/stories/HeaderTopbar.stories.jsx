// Rendert echte shadcn-Komponenten: Avatar
import { HeaderTopbar } from '../components/HeaderTopbar';

export default {
  title: 'Organisms/Header Topbar',
  component: HeaderTopbar,
};

export const Default = {};
