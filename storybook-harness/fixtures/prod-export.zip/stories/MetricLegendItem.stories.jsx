import { MetricLegendItem } from '../components/MetricLegendItem';

export default {
  title: 'Molecules/Metric Legend Item',
  component: MetricLegendItem,
};

export const Default = {};
