// Rendert echte shadcn-Komponenten: Button, Card
import { IncomeBreakdownCard } from '../components/IncomeBreakdownCard';

export default {
  title: 'Organisms/Income Breakdown Card',
  component: IncomeBreakdownCard,
};

export const Default = {};
