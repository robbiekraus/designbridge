// Rendert echte shadcn-Komponenten: Card
import { TopProductsTableCard } from '../components/TopProductsTableCard';

export default {
  title: 'Organisms/Top Products Table Card',
  component: TopProductsTableCard,
};

export const Default = {};
