import { Badge } from '../components/ChartLineTooltipBadge';

export default {
  title: 'Atoms/Chart Line Tooltip Badge',
  component: Badge,
};

export const Default = {};
export const Secondary = { args: { variant: 'secondary' } };
