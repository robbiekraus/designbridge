// Rendert echte shadcn-Komponenten: Button, Card
import { YourSalesChartCard } from '../components/YourSalesChartCard';

export default {
  title: 'Organisms/Your Sales Chart Card',
  component: YourSalesChartCard,
};

export const Default = {};
