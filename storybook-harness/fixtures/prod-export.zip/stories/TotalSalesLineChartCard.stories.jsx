// Rendert echte shadcn-Komponenten: Card
import { TotalSalesLineChartCard } from '../components/TotalSalesLineChartCard';

export default {
  title: 'Organisms/Total Sales Line Chart Card',
  component: TotalSalesLineChartCard,
};

export const Default = {};
