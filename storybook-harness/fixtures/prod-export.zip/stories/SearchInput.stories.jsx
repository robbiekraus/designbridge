import { Input } from '../components/SearchInput';

export default {
  title: 'Molecules/Search Input',
  component: Input,
};

export const Default = {};
export const Disabled = { args: { variant: 'disabled' } };
