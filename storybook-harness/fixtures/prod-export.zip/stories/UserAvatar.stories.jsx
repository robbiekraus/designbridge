// Rendert echte shadcn-Komponenten: Avatar
import { UserAvatar } from '../components/UserAvatar';

export default {
  title: 'Atoms/User Avatar',
  component: UserAvatar,
};

export const Default = {};
