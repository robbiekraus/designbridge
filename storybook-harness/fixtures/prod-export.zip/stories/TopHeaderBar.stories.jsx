// Rendert echte shadcn-Komponenten: Button
import { TopHeaderBar } from '../components/TopHeaderBar';

export default {
  title: 'Organisms/Top Header Bar',
  component: TopHeaderBar,
};

export const Default = {};
