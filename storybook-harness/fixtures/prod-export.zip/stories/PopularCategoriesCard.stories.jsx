// Rendert echte shadcn-Komponenten: Card
import { PopularCategoriesCard } from '../components/PopularCategoriesCard';

export default {
  title: 'Organisms/Popular Categories Card',
  component: PopularCategoriesCard,
};

export const Default = {};
