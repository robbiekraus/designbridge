import { Badge } from '../components/BadgeTrend';

export default {
  title: 'Atoms/Badge Trend',
  component: Badge,
};

export const Default = {};
export const Secondary = { args: { variant: 'secondary' } };
