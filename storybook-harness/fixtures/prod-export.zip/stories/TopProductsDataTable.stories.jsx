// Rendert echte shadcn-Komponenten: Card
import { TopProductsDataTable } from '../components/TopProductsDataTable';

export default {
  title: 'Organisms/Top Products Data Table',
  component: TopProductsDataTable,
};

export const Default = {};
