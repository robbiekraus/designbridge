// Rendert echte shadcn-Komponenten: Avatar, Button, Card
import { LeftSidebarNavigation } from '../components/LeftSidebarNavigation';

export default {
  title: 'Organisms/Left Sidebar Navigation',
  component: LeftSidebarNavigation,
};

export const Default = {};
