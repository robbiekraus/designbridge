// Rendert echte shadcn-Komponenten: Button, Card
import { DashboardPageLayout } from '../components/DashboardPageLayout';

export default {
  title: 'Templates/Dashboard Page Layout',
  component: DashboardPageLayout,
};

export const Default = {};
