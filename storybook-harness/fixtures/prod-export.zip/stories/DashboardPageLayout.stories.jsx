// Rendert echte shadcn-Komponenten: Avatar, Button, Card, Input
import { DashboardPageLayout } from '../components/DashboardPageLayout';

export default {
  title: 'Templates/Dashboard Page Layout',
  component: DashboardPageLayout,
};

export const Default = {};
