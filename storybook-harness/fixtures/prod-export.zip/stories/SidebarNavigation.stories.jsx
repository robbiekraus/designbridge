import { SidebarNavigation } from '../components/SidebarNavigation';

export default {
  title: 'Organisms/Sidebar Navigation',
  component: SidebarNavigation,
};

export const Default = {};
