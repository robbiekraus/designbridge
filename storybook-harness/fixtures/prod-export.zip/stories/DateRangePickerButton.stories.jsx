import { Button } from '../components/DateRangePickerButton';

export default {
  title: 'Molecules/Date Range Picker Button',
  component: Button,
};

export const Default = {};
export const Primary = { args: { variant: 'primary' } };
export const Secondary = { args: { variant: 'secondary' } };
export const Ghost = { args: { variant: 'ghost' } };
