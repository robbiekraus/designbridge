// Rendert echte shadcn-Komponenten: Card
import { ProductShareDonutCard } from '../components/ProductShareDonutCard';

export default {
  title: 'Organisms/Product Share Donut Card',
  component: ProductShareDonutCard,
};

export const Default = {};
