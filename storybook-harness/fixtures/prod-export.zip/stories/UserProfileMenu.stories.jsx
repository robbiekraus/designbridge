// Rendert echte shadcn-Komponenten: Avatar
import { UserProfileMenu } from '../components/UserProfileMenu';

export default {
  title: 'Molecules/User Profile Menu',
  component: UserProfileMenu,
};

export const Default = {};
