// Rendert echte shadcn-Komponenten: Card
import { TotalOrderSparklineCard } from '../components/TotalOrderSparklineCard';

export default {
  title: 'Organisms/Total Order Sparkline Card',
  component: TotalOrderSparklineCard,
};

export const Default = {};
