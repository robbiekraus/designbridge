import { Badge } from '../components/TrendIndicatorBadge';

export default {
  title: 'Atoms/Trend Indicator Badge',
  component: Badge,
};

export const Default = {};
export const Secondary = { args: { variant: 'secondary' } };
