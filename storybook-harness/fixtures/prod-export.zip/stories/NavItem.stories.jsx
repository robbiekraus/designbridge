import { NavItem } from '../components/NavItem';

export default {
  title: 'Molecules/Nav Item',
  component: NavItem,
};

export const Default = {};
