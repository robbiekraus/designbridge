import { TimePeriodFilter } from '../components/TimePeriodFilter';

export default {
  title: 'Molecules/Time Period Filter',
  component: TimePeriodFilter,
};

export const Default = {};
