import { ProgressBar } from '../components/ProgressBar';

export default {
  title: 'Atoms/Progress Bar',
  component: ProgressBar,
};

export const Default = {};
