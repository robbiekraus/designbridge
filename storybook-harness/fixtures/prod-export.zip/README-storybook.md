# DesignBridge — Storybook-Paket

Aus einem Scan erzeugte Komponenten samt Stories (Component Story Format).

## Reinlegen

1. In ein bestehendes React+Vite-Projekt kopieren (oder `npx storybook@latest init`).
2. `components/` und `stories/` sowie `.storybook/main.js` übernehmen.
3. `npm run storybook` — die Bausteine erscheinen nach Ebene gruppiert.

## Inhalt

- `stories/BrandLogo.stories.jsx`
- `stories/Avatar.stories.jsx` — shadcn: Avatar
- `stories/BadgeTrend.stories.jsx`
- `stories/ProgressBar.stories.jsx`
- `stories/NavItem.stories.jsx`
- `stories/SearchInput.stories.jsx`
- `stories/DateRangePickerButton.stories.jsx`
- `stories/UserProfileMenu.stories.jsx` — shadcn: Avatar
- `stories/MetricIndicatorBlock.stories.jsx`
- `stories/ProductTableRow.stories.jsx`
- `stories/SidebarNavigation.stories.jsx`
- `stories/HeaderTopbar.stories.jsx` — shadcn: Avatar
- `stories/KpiCardBlock.stories.jsx` — shadcn: Card
- `stories/TotalSalesLineChartCard.stories.jsx` — shadcn: Card
- `stories/ShoppingCartPerformanceCard.stories.jsx` — shadcn: Card
- `stories/TopProductsTableCard.stories.jsx` — shadcn: Card
- `stories/ProductShareDonutCard.stories.jsx` — shadcn: Card
- `stories/TotalOrderSparklineCard.stories.jsx` — shadcn: Card
- `stories/DashboardScreenLayout.stories.jsx` — shadcn: Avatar, Button, Card, Input
