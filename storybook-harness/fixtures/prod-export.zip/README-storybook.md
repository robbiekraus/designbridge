# DesignBridge — Storybook-Paket

Aus einem Scan erzeugte Komponenten samt Stories (Component Story Format).

## Reinlegen

1. In ein bestehendes React+Vite-Projekt kopieren (oder `npx storybook@latest init`).
2. `components/` und `stories/` sowie `.storybook/main.js` übernehmen.
3. `npm run storybook` — die Bausteine erscheinen nach Ebene gruppiert.

## Inhalt

- `stories/NavIcon.stories.jsx`
- `stories/UserAvatar.stories.jsx` — shadcn: Avatar
- `stories/ChartLineTooltipBadge.stories.jsx`
- `stories/TimePeriodFilter.stories.jsx`
- `stories/CategoryItemRow.stories.jsx`
- `stories/EventListItem.stories.jsx`
- `stories/MetricLegendItem.stories.jsx`
- `stories/LeftSidebarNavigation.stories.jsx` — shadcn: Avatar, Button, Card
- `stories/TopHeaderBar.stories.jsx` — shadcn: Button
- `stories/PopularCategoriesCard.stories.jsx` — shadcn: Card
- `stories/YourSalesChartCard.stories.jsx` — shadcn: Button, Card
- `stories/LatestEventsCard.stories.jsx` — shadcn: Button, Card
- `stories/ConversionHistoryCard.stories.jsx` — shadcn: Card
- `stories/IncomeBreakdownCard.stories.jsx` — shadcn: Button, Card
- `stories/IncomeDetailsCard.stories.jsx` — shadcn: Card
- `stories/DashboardPageLayout.stories.jsx` — shadcn: Button, Card
