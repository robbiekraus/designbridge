# DesignBridge — Storybook-Paket

Aus einem Scan erzeugte Komponenten samt Stories (Component Story Format).

## Reinlegen

1. In ein bestehendes React+Vite-Projekt kopieren (oder `npx storybook@latest init`).
2. `components/` und `stories/` sowie `.storybook/main.js` übernehmen.
3. `npm run storybook` — die Bausteine erscheinen nach Ebene gruppiert.

## Inhalt

- `stories/BrandLogo.stories.jsx`
- `stories/TrendIndicatorBadge.stories.jsx`
- `stories/UserAvatar.stories.jsx` — shadcn: Avatar
- `stories/ProgressBar.stories.jsx`
- `stories/SearchInput.stories.jsx`
- `stories/DateRangeFilterDropdown.stories.jsx`
- `stories/SidebarNavLink.stories.jsx`
- `stories/ProductTableRow.stories.jsx`
- `stories/SidebarNavigation.stories.jsx`
- `stories/HeaderTopbar.stories.jsx` — shadcn: Avatar
- `stories/KpiStatCard.stories.jsx` — shadcn: Card
- `stories/TotalSalesLineChartCard.stories.jsx` — shadcn: Card
- `stories/ShoppingCartPerformanceCard.stories.jsx` — shadcn: Card
- `stories/TopProductsDataTable.stories.jsx` — shadcn: Card
- `stories/ProductShareDonutChartCard.stories.jsx` — shadcn: Card
- `stories/TotalOrderSparklineCard.stories.jsx` — shadcn: Card
- `stories/DashboardPageLayout.stories.jsx` — shadcn: Avatar, Button, Card, Input
